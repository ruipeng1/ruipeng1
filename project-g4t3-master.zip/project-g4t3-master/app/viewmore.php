<?php
    require_once "include/protect.php";
    require_once "include/common.php";
    echo "<!-- Custom styles for this template -->
    <link href='css/test.css' rel='stylesheet'>
    <!-- Bootstrap core CSS -->
    <link href='vendor/bootstrap/css/bootstrap.min.css' rel='stylesheet'>
    <script src='vendor/jquery/jquery.min.js'></script>
    <script src='vendor/bootstrap/js/bootstrap.bundle.min.js'></script>";
    $dao = new StudentDAO();
    $userid = $_SESSION['userid'];
    $roundDAO = new RoundnumDAO();
    $currRound = $roundDAO->retrieveAll()->getRound();
    if ($currRound==2){
        require_once "round2_logic.php";
    }  

    $courseDAO= new CourseDAO;
    $sectionDAO= new SectionDAO;
    $enrollDAO = new EnrolledDAO;
    $minBid = new minBidDAO;
    if (isset($_GET["course_section"])){
        $str=$_GET["course_section"];
        $row = explode(",",$str);
        $courseID=$row[0];
        $sectionID=$row[1];
        $course=$courseDAO->retrieve($courseID);
        $section= $sectionDAO->retrieve($courseID,$sectionID);
        $min = $minBid->retrieve_bid($courseID,$sectionID);
    }

    // to convert day nums to actual days
    $days = [1 => "Monday", 2 => "Tuesday", 3 => "Wednesday", 4 => "Thursday", 5 => "Friday", 6=> "Satutday", 7 => "Sunday"];

    $sec_day=$section->getDay();

    if(array_key_exists($sec_day,$days)){
        $sec_day=$days[$sec_day];
    }

// ------------------------------------------------------Display Course Info--------------------------------------------------------------//
    echo "<br>
    <div class='container'>
        <div class='row'>
            <div >";
    echo "<table class=' table-sm table-striped'>";

    echo "<tr>
            <th>CourseID</th>
            <td>$courseID</td>
         </tr>
         <tr>
            <th>Course Name</th>
            <td>{$course->getTitle()}</td>
        </tr>
         <tr>
            <th>Section</th>
            <td>$sectionID</td>
         </tr>
         <tr>
            <th>Class Day/Time</th>
            <td>$sec_day  / {$section->getStart()}-{$section->getEnd()}</td>
        </tr>
        
        <tr>
            <th>School</th>
            <td>{$course->getSchool()}</td>
        </tr>
        <tr>
            <th>Description</th>
            <td>{$course->getDescription()}</td>
        </tr>
        <tr>
            <th>Exam Date/Time</th>
            <td>{$course->getExam_date()}   / {$course->getExam_start()}-{$course->getExam_end()}</td>
        </tr>
        <tr>
            <th>Instructor</th>
            <td>{$section->getInstructor()}</td>
        </tr>
        <tr>
            <th>Venue</th>
            <td>{$section->getVenue()}</td>
        </tr>";
    $size=$section->getSize();
    if ($currRound!=2){
        echo"
        <tr>
            <th>Class Vacancy</th>
            <td>$size</td>
        </tr>";
    }else{
        $size_after_round1=$size+sizeof($enrolledDAO->retrieve_success_enrolled($courseID,$sectionID,"2"));
        echo
        "
        <tr>
            <th>Available Seats (After Round 1)</th>
            <td>$size_after_round1</td>
        </tr>";
     
    }
    //show the real time min bid in round 2
    if ($currRound==2){
        if ($min->getedollar()==10.001){//if minbid was set to be 10.001, means it was filled in round 1
            echo"
                <tr>
                    <th>Minimum Bid</th>
                    <td>The section has 0 vacancy after Round 1. You will see the minimum bid only if someone drops this section.</td>
                </tr>";
        }else{
            echo"
                <tr>
                    <th>Minimum Bid</th>
                    <td>{$min->getedollar()}</td>
                </tr>";
        }
    }
    echo"
        </table>
        
        <a href = 'cart.php?course_to_cart[]=$courseID,$sectionID'>Add to cart
        <br>
        <a href = 'search_for_courses.php'>Go back to Course Search Page
        </div>
        </div>
        </div>
        ";

      





?>

