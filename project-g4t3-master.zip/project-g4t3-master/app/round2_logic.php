<?php
require_once "include/common.php";
//---------------------------------------------Bidding 2 Clearing Logic -------------------------------------------------
$bidDAO = new BidDAO();
$sectionDAO = new SectionDAO();
$enrolledDAO=new EnrolledDAO();
$minBidDAO= new minBidDAO();
$roundDAO = new RoundnumDAO();
$all_sectionArr = $sectionDAO->retrieveAll();
$currRound = $roundDAO->retrieveAll()->getRound();
$each_sect_clearing_bid=[];



if($currRound == 2){
	
    //store unique course and section with clearing amount
    $each_sect_clearing_bid = [];

    foreach($all_sectionArr as $sectObj){

        $bidObjArr = [];
        
        $sectCourse = $sectObj -> getCourse();
        $sectNo =  $sectObj -> getSection();
		$sectSize = $sectObj->getSize();

		//before the logic start, drop all the enrolled bids for this section
		$no_of_success_enrolls=sizeof($enrolledDAO->retrieve_success_enrolled($sectCourse,$sectNo,"2"));

		$sectionDAO->updateSize($sectCourse,$sectNo,$no_of_success_enrolls);

        $enrolledDAO->drop_section($sectCourse,$sectNo,"2");
        
        //Debug:
	
        // Array of all the bids objects for this section
		$bidObjArr  = $bidDAO->orderCourseByDesc($sectCourse, $sectNo);//var_dump($bidObjArr);
        
        $clearingAmt = 10;
        $sectSize+=$no_of_success_enrolls;

		if(!empty($bidObjArr) && $sectSize>0){//if there are bids for the section
	
            if((sizeof($bidObjArr) > $sectSize)){//if no. of bids greater than section size
                //Let N be the section size, find the Nth bid 
    			$nth_row_bid_obj = $bidObjArr[$sectSize-1];
				
                //get the Nth bid amount, which will be the clearing price
                $nth_row_bid_amt = $nth_row_bid_obj->getAmount();
				$lowest_amt = $nth_row_bid_amt;#var_dump($lowest_amt);
				

                //to count how many bids at the clearing price
                $count_no_of_bids_at_clearing_price=0;

				foreach($bidObjArr as $bid){
				    if(( ($bid->getAmount())==$nth_row_bid_amt )){
				        $count_no_of_bids_at_clearing_price++;
				    }
				}//
				
				//get the (N+1)th bid amount, if it is not the lowest price, means all bids at the lowest price can be accommodated
				$next_row_bid_obj = $bidObjArr[$sectSize];
                $next_row_bid_amt = $next_row_bid_obj->getAmount();
				

				//all the bids at this price will fail if (N+1)th bid amount is also the lowest price
                if (($count_no_of_bids_at_clearing_price>1) && ($nth_row_bid_amt==$next_row_bid_amt)){
					
                    $clearingAmt=$lowest_amt+1;
					foreach($bidObjArr as $bid){
						$amt=$bid->getAmount();
                        if($amt>$lowest_amt){//if bidding amount > clearing price ---------> successful
                            $addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'successful');
                            $enrolledDAO->add_enrolled($addEnroll);
							$sectionDAO->updateSize($bid->getCourse(),$bid->getSection(),-1);

                        }else{//if bidding amount <= clearing price --------> unsuccessful
							$addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'unsuccessful');
                            $enrolledDAO->add_enrolled($addEnroll);
							
						}
					}
				
					
				}else{//if one or more bids at the clearing price and all can be accommodated, all the bids >= this price will be successful
					foreach($bidObjArr as $bid){
						$amt=$bid->getAmount();
						$clearingAmt=$lowest_amt+1;
                        if($amt>=$lowest_amt){//if bidding amount >= clearing price ---------> successful
                            $addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'successful');
                            $enrolledDAO->add_enrolled($addEnroll);
                            $sectionDAO->updateSize($bid->getCourse(),$bid->getSection(),-1);
							
                        }else{//if bidding amount < clearing price --------> unsuccessful
							$addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'unsuccessful');
                            $enrolledDAO->add_enrolled($addEnroll);
							
						}
                    }

				}

                    
			}else if (sizeof($bidObjArr) == $sectSize){
				$nth_row_bid_obj = $bidObjArr[$sectSize-1];
                $clearingAmt = ($nth_row_bid_obj->getAmount())+1;
                foreach($bidObjArr as $bid){
                    $addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'successful');
                    $enrolledDAO->add_enrolled($addEnroll);
                    $sectionDAO->updateSize($bid->getCourse(),$bid->getSection(),-1);
                    
                }

			
			
			}else{//if num of bids less than the section size
				$clearingAmt = 10;
				
                foreach($bidObjArr as $bid){
                    $addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'successful');
                    $enrolledDAO->add_enrolled($addEnroll);
                    $sectionDAO->updateSize($bid->getCourse(),$bid->getSection(),-1);
                    
                }
			}
			
			
			
        }elseif(!empty($bidObjArr) && $sectSize==0){
            $clearingAmt = 10.001;//special value to indicate that the section is full in round 1 
            foreach($bidObjArr as $bid){
                $amt=$bid->getAmount();
                $addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'unsuccessful');
                $enrolledDAO->add_enrolled($addEnroll);
                    
                }
        }

        // to update the minBid only when the new clearing price increase
        if ($minBidDAO->retrieve_bid($sectCourse,$sectNo)!=[]){
            $existing_min_bid=$minBidDAO->retrieve_bid($sectCourse,$sectNo)->getedollar();
        }else{
            $existing_min_bid=10;
        }
        
        if( ($clearingAmt > $existing_min_bid) && ($existing_min_bid!=10.001) ){
            $new_minBid= new minBid($sectCourse,$sectNo,$clearingAmt);
            $minBidDAO->update($new_minBid);
        }elseif($existing_min_bid==10.001){
            $new_minBid= new minBid($sectCourse,$sectNo,$clearingAmt);
            $minBidDAO->update($new_minBid);
        }
           
   
    }
}


?>