<?php
require_once "include/common.php";
// require_once "include/protect_admin.php";


//---------------------------------------------Round 2 STOPPING Logic-------------------------------------------------
$bidDAO = new BidDAO();
$sectionDAO = new SectionDAO();
$enrollDAO=new EnrolledDAO();
$minBid= new minBidDAO();
$all_sectionArr = $sectionDAO->retrieveAll();
$roundDAO = new RoundnumDAO();
$currRound = $roundDAO->retrieveAll()->getRound();
$each_sect_clearing_bid=[];



if($currRound == "stop2"){
	$all_unsuccess_bids = $enrollDAO->retrieve_unsuccess_enrolled("2");
	foreach($all_unsuccess_bids as $item){
		$user=$item->getUserid();
		$amt=$item->getAmount();
		$enrollDAO->refund_when_unsuccessful($user,$amt);
	}
	// remove all bids
	$bidDAO->removeAll();
}
?>