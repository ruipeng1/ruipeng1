<?php
require_once "include/common.php";
require_once "include/protect_admin.php";

$round = 2;
$roundDAO = new RoundnumDAO();
$update = $roundDAO->update($round);

require_once "round2_logic.php";



header ("Location: admin_index.php");
exit;
?>