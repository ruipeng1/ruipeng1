<?php
require_once "include/protect.php";
require_once "include/common.php";

$nav_tab = "Cart";
$nav_tab_url = "cart.php";
$nav_tab_1 = "Logout";
$nav_tab_url_1 = "logout.php";
$nav_tab_2 = "Home";
$nav_tab_url_2 = "student_index.php";

$studentDAO = new StudentDAO();
$bidDAO = new BidDAO();
$userid = $_SESSION['userid'];
$user = $studentDAO->retrieve($userid);
$name = $user ->getName();
$edollar = $user->getEdollar();
$noSelectMsg = "";
$courseInCartMsg = [];
//
$errorMsg=[];
$successBidAmtArr = [];

//
$enrolledDAO=new EnrolledDAO();
$bids_in_cart=[];
$bid_in_cartDAO=new Bid_in_cartDAO;
$sectionCount = 0;
$count_course = 0;
$retr_in_bid = $bidDAO->retrieve($userid);
$count_course = count($retr_in_bid);
$sectionCount = $count_course;


if(isset($_GET["course_to_cart"])){

  
    //check if bid in cart alrdy exist in bid db
    //if exist, start counting, ensure the user cannot excceed 5
    // dont push to bid_in_cart
    //prompt error that the bid for this course and section are placed
    
    $courses_to_cart=$_GET["course_to_cart"];
    foreach($courses_to_cart as $item){
        //split and store in bid_in_cart
        $item = explode(",",$item);
        $bids_in_cart[]= new Bid_in_cart($userid,$item[0],$item[1]);
    }
  
    # to check if the section alr in the cart
    $arr=$bid_in_cartDAO->retrieve($userid);
    foreach ($bids_in_cart as $item){
        if (in_array($item,$arr)){
            $courseInCartMsg[] = "{$item->getCourse()} ,{$item->getSection()} has successfully added into your cart!<br>";
            #to remove
            $pos = array_search($item, $bids_in_cart);
            unset($bids_in_cart[$pos]);
        }
    }

    # Load data into bids_in_cart table in database
    #less than or equals to 5 sections
    if($count_course<=5){
        foreach ($bids_in_cart as $item){
            $bid_in_cartDAO->add_to_cart($item);
        }

    }else{
        $_SESSION['errors'][]="You can only bid a maximum of 5 sections ";
    }
    }else{
   }

if(!empty($_SESSION['errors'])){
    header("Location:search_for_courses.php");
}
#To pull data from bids_in_cart table in database and display
$arr=$bid_in_cartDAO->retrieve($userid);
$courseDAO=new CourseDAO();
$sectionDAO = new SectionDAO();

    
    

?>


<!DOCTYPE html>
<html lang="en">
    <?php require_once 'include/head.php'; ?>   
    <body>
        <?= require_once 'include/nav.php'?>
        

        <div class="container"  >
            <div class="jumbotron">
                <div style ="text-align:center;!important">
                    <nav aria-label="breadcrumb" >
                        <ol class="breadcrumb" >
                            <li class="breadcrumb-item"><a href="student_index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="search_for_courses.php">Search</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Cart</li>
                        </ol>
                    </nav>
                </div>
                <?php 
                $roundDAO = new RoundnumDAO; 
                $round = $roundDAO->retrieveAll()->getRound(); 
                if ($round == "1" || $round == "2"){
                    echo "<h1 class='display-6' style ='text-align:center;'>ROUND {$round} BIOS BIDDING</h1>"; 
                }
                elseif ($round == "stop1"){
                    echo '<h1 class="display-6" style ="text-align:center;">ROUND 1 BIOS BIDDING ENDED</h1>'; 
                }
                elseif ($round == "stop2"){
                    echo '<h1 class="display-6" style ="text-align:center;">ROUND 2 BIOS BIDDING ENDED</h1>';
                }
                
                ?> 
                    
                <p  style ="text-align:center;">You currently have<br/><b style="font-size: 40px;"><?=$edollar?></b><br/>edollars</p>   
            </div>
        

            <?php 
                
                if(!empty($arr)){
                    echo $noSelectMsg;
                    if(!empty($courseInCartMsg)){
                        for($i = 0; $i<count($courseInCartMsg); $i++){
                            echo $courseInCartMsg[$i];
                        }
                    }
            ?>
            <div class="row">
                <div class="col">
                    <form action="cart.php" method="GET">
                
                        <table class='table table-sm table-striped '>
                            <thead>
                                <tr>
                                <th></th>
                                <th>Course Code</th>
                                <th>Course Title</th>
                                <th>Section</th>
                                <th>Bidding Amount</th>
                                </tr>
                            </thead>
            
            
                    <?php
                        foreach($arr as $index => $item){

                            $courseID=$item->getCourse();
                            $course=$courseDAO->retrieve($courseID);
                            $course_title=$course->getTitle();
                            $section=$item->getSection();

                            echo "
                                <tr>
                                <td><input type='checkbox' name='bids[$index]' value='$courseID,$section'</td>
                                <td>$courseID</center></td>
                                <td>$course_title</td>
                                <td>$section</td>
                                <td><label style='padding-right:20px;'>$</label><input type='text'  name='bidding_amt[$index]' style='width:50px; '></td>
                                </tr>";
                    
                        }
                            echo "</table>";

                            $currround = $roundDAO->retrieveAll()->getRound();
                            if($currround!="stop1" && $currround!="stop2"){
                                echo '<button type="submit"  value="Submit your bid" class="btn btn-secondary btn-sm" name = "submitBid">Submit your bid</button>';
                            }else{
                                echo "The bidding round has ended. You are not allowed to bid at this time.";
                            }
                    ?>

                        
                       
                        <button type="submit"  value="clear your bid" class="btn btn-secondary btn-sm" name = "clearBid">Delete from cart</button>
                    </form>
                </div>
                <div class="col">
                </div>
            </div>
        </div><!--end container-->


        <?php

            }//end if empty arr 
            else{
                echo "Your cart is currently empty";
            }
        ?>
    </body>
</html>

<?php
//--------------------------------------------process logic for impossible bid

$roundDAO = new RoundnumDAO();
$currRound = $roundDAO->retrieveAll()->getRound();
$cartDAO = new Bid_in_cartDAO();
$courseCompleteDAO = new Course_completedDAO();
#$delCart = $cartDAO->delete();
if(isset($_GET["clearBid"])){
    $clearBidArr = [];
    $delSelBid = [];

    #checked/select bids in cart
    if(isset($_GET["bids"])){
        $clearBidArr=$_GET["bids"];
         foreach($clearBidArr as $clearItems){
            $clearItems = explode(",",$clearItems);
            //add into array to delete from cart by calling Bid_in_cartDAO using delete($bid_in_cart)
            $delSelBid[] = new Bid_in_cart($userid,$clearItems[0],$clearItems[1]);
        }
        foreach($delSelBid as $clearEachSelectedItems){
            $cartDAO->delete($clearEachSelectedItems);
        }        
        echo "<meta http-equiv='refresh' content='0;url=cart.php'>";
    }else{
        //not selected any to clear the bids in cart
        exit;
    }
    
    
}
if(isset($_GET["submitBid"])){
    $bidArr  = [];
    $bidAmtArr = [];
    $errorMsg = []; 
    $successBidArr = [];
    $successBidAmtArr = [];

    
    //get course, section, amount from bid table and compare with bid_in_cart table
    $minbidDAO= new minBidDAO;
    if(isset($_GET["bidding_amt"])&&isset($_GET["bids"])){

        
        $bidAmtArr = $_GET["bidding_amt"];
        $bidArr    = $_GET["bids"];
        $loop = count($bidAmtArr);

        //----------------------------to retrieve multiple textbox values + selected values---------------
        for($i = 0; $i<$loop;$i++){
            if(!empty($bidAmtArr[$i]) && !empty($bidArr[$i])){
                // check if bid value is less than 10 or non numeric or non negative
                $strArr = explode(',', $bidArr[$i]);
                $courseCode = $strArr[0];
                $section = $strArr[1];
                $minbid=$minbidDAO->retrieve_bid($courseCode,$section)->getedollar();
                if (!isNonNegative($bidAmtArr[$i])||$bidAmtArr[$i] < 10||(($bidAmtArr[$i]< $minbid) && ($currRound=="2"))){
                    if($bidAmtArr[$i] < 10){
                        $errorMsg[] = "$bidAmtArr[$i] is an invalid amount. Please bid more than e$10";
                    }else if(($bidAmtArr[$i]< $minbid) && ($currRound=="2")){
                    $errorMsg[] = "You bidding amount is lower than the minimum bid!";
                    }else{
                        $errorMsg[] = "$bidAmtArr[$i] is an invalid amount";
                    }  

                }else{
                    $successBidArr[] = $bidArr[$i];
                    $successBidAmtArr[] = $bidAmtArr[$i];
                }
                    
                

            }else if(!empty($bidArr[$i]) && empty($bidAmtArr[$i])) {
                $errorMsg[] = "Please input amount for ". $bidArr[$i];

            }else if(!empty($bidAmtArr[$i]) && empty($bidArr[$i])){
                $errorMsg[] = "Added amount $bidAmtArr[$i] but course not selected";
            }
        }
    }
    else{
        $errorMsg[]= "Please select the bids that you want to submit!";
    }
        

        $allStudentArr = [];
        
        $student_sch = $studentDAO->retrieve($userid)->getSchool();
        $courses_by_school = getCoursesBySch($student_sch);	

        $courseArr = [];
        
        //*new*
        $bidded_courseArr=[];
        
        $biddeds=$bidDAO->retrieve($userid);;

        foreach($biddeds as $bidded){
            $bidded_courseArr[]=$bidded->getCourse();
        }

        
        //*new*        
        $enrolled_courseArr=[];
        $enrolled_sections=$enrolledDAO->retrieve_user_success_enrolled($userid);

        foreach($enrolled_sections as $obj){
            $enrolled_courseArr[]=$obj->getCourse();
        }

        $enrolledCount = 0;
        $r1_enrolled_sections=$enrolledDAO->retrieve_round_success($userid,"stop1");
        $enrolledCount = count($r1_enrolled_sections);

        //-- end new
        
        $totalBidAmt = 0;

        $bidEntitled = $studentDAO->retrieve($userid)->getEdollar();


        //------------- store bided values in studentArr [time]---------
        $bidedValuesArr = $bidDAO->retrieve($userid);
        $currStudentInfo = [];
        if($bidedValuesArr){
            foreach($bidedValuesArr as $objVal){
                $courseCode1 = $objVal->getCourse();
                $section1 = $objVal -> getSection();
    
                $curr_section_time_start1 = $sectionDAO ->retrieve($courseCode1, $section1)->getStart();
                $curr_section_time_end1 = $sectionDAO ->retrieve($courseCode1, $section1)->getEnd();
    
                $curr_exam_time_start1 = $courseDAO ->retrieve($courseCode1)->getExam_start();
                $curr_exam_time_end1 = $courseDAO ->retrieve($courseCode1)->getExam_end();
    
    
                $curr_exam_date1 = $courseDAO ->retrieve($courseCode1)->getExam_date();
                $curr_section_day1 = $sectionDAO ->retrieve($courseCode1, $section1)->getDay();
    
    
                $currStudentInfo["start"] = $curr_section_time_start1;
                $currStudentInfo["end"] = $curr_section_time_end1;
                $currStudentInfo["examstart"] = $curr_exam_time_start1;
                $currStudentInfo["examend"] = $curr_exam_time_end1;
    
                $currStudentInfo["examdate"] = $curr_exam_date1;
                $currStudentInfo["day"] = $curr_section_day1;
                
                $allStudentArr[$userid] = $currStudentInfo;
    
    
            }
        }
        

        
        //var_dump($successBidArr);
        //------------------------------------process logic validation 
        if(!empty($successBidArr) && empty($errorMsg)){
            
            for($i = 0; $i<count($successBidArr); $i++){
                //loop line by line from the selected check box
                $strArr = explode(',', $successBidArr[$i]);
                $courseCode = $strArr[0];
                $section = $strArr[1];
                

                //to check if select courses is from own school (pre-flitered in the search_for_courses.php)
                if($currRound == "1"){
                    if (in_array($courseCode, $courses_by_school) == false){
                        
                        $errorMsg[] = "$courseCode is not from your school. Please bid only your own school course in current round";
                    // echo"$courseCode is not from your school. Please bid only your own school course in current round";
                    }
                }


                // to check if prereq is completed
                if(!empty(checkPreReqExist($courseCode))){
                    $prereqCourses = checkPreReqExist($courseCode);
                    for($pc = 0; $pc<count($prereqCourses);$pc++){
                        if (checkCourseCompleted($userid, $prereqCourses[$pc])==false){
                            $errorMsg[] = "$courseCode has incomplete prerequisite";
                        }
                    }
                }

                // to check if course has been completed
                if($courseCompleteDAO->retrieveSpecific($userid, $courseCode) != null){
                    $errorMsg[] = "$courseCode is completed";
                }
                
                
                
        
                if(in_array($courseCode, $courseArr) || in_array($courseCode, $bidded_courseArr)||in_array($courseCode,$enrolled_courseArr)){
                    if(in_array($courseCode, $courseArr)){
                        $errorMsg[] = "Multiple $courseCode selected. Only one section per course";
                    }else{
                        $errorMsg[] = "$courseCode is already bidded";
                    }


                }else{
                    $courseArr[] = $courseCode;
                    //----------------------------------- check time clash for diff courses--------
                    $currStudentInfo = [];

                    $curr_section_time_start = $sectionDAO ->retrieve($courseCode, $section)->getStart();
                    $curr_section_time_end = $sectionDAO ->retrieve($courseCode, $section)->getEnd();

                    $curr_exam_time_start = $courseDAO ->retrieve($courseCode)->getExam_start();
                    $curr_exam_time_end = $courseDAO ->retrieve($courseCode)->getExam_end();


                    $curr_exam_date = $courseDAO ->retrieve($courseCode)->getExam_date();
                    $curr_section_day = $sectionDAO ->retrieve($courseCode, $section)->getDay();

                    
                    if (array_key_exists($userid, $allStudentArr)){

                        foreach($allStudentArr as $infoDataArr){
                            $existStart = $infoDataArr["start"];
                            $existEnd = $infoDataArr["end"];
                            $existExamS = $infoDataArr["examstart"];
                            $existExamE = $infoDataArr["examend"];
                            
                            $classNotClash= false;
						    $examNotClash= false;
                            
                            if(checkTimeClash2($curr_section_time_start,$curr_section_time_end, $existStart,$existEnd) && $curr_section_day == $infoDataArr["day"] ){
                                $errorMsg[] = "class timetable clash";

                            }else{
								$classNotClash= true;
							}
                            
                            
                            if (checkTimeClash2($curr_exam_time_start,$curr_exam_time_end, $existExamS,$existExamE) && $curr_exam_date == $infoDataArr["examdate"]){
                                $errorMsg[] = "exam timetable clash";					
                            }else{
								$examNotClash = true;
							}
                            
                                
                            if($examNotClash && $classNotClash){
                                $currStudentInfo["start"] = $curr_section_time_start;
                                $currStudentInfo["end"] = $curr_section_time_end;
                                $currStudentInfo["examstart"] = $curr_exam_time_start;
                                $currStudentInfo["examend"] = $curr_exam_time_end;

                                $currStudentInfo["examdate"] = $curr_exam_date;
                                $currStudentInfo["day"] = $curr_section_day;

                                array_push($allStudentArr[$userid], $currStudentInfo);
                                $noClashOk = true;	
                            }
                        }		
                    }else{
                        $currStudentInfo["start"] = $curr_section_time_start;
                        $currStudentInfo["end"] = $curr_section_time_end;
                        $currStudentInfo["examstart"] = $curr_exam_time_start;
                        $currStudentInfo["examend"] = $curr_exam_time_end;

                        $currStudentInfo["examdate"] = $curr_exam_date;
                        $currStudentInfo["day"] = $curr_section_day;
                        
                        $allStudentArr[$userid] = $currStudentInfo;
                        $noClashOk = true;
                    }//end check for time clash
                    //---
                }//end check duplicate course
                $courseArr = [];

                //add edollar
                $totalBidAmt += $successBidAmtArr[$i];
                if($totalBidAmt > $bidEntitled){
                    $errorMsg[] = "You do not enough e-dollar, please place a lower amount";
                }
                
                if(empty($errorMsg)){
                    $sectionCount += 1;
                    if($sectionCount + $enrolledCount > 5){
                        $errorMsg[] = "section limit reach";
                    }   
                }
    

            }//end of loop bid

            //check for enough edollar

            
        }  //end if empty success bid arr  	
    }   

    //var_dump($errorMsg);
    
    $_SESSION['errors']=$errorMsg;
    if(!empty($errorMsg)){
        printErrors();
        $errorMsg=null;
    }else{
        
        for($i = 0; $i<count($successBidAmtArr); $i++){
            $strArr = explode(',', $successBidArr[$i]);
            $code = $strArr[0];
            $section = $strArr[1];
            $bidObj = new Bid($userid,$successBidAmtArr[$i], $code, $section);
            $bidDeduct = new Bid($userid,$successBidAmtArr[$i]);
            //add to bid as "pending"
            $bidDAO->add($bidObj);
            //deduct edollar
            $bidDAO->deduct_when_add($bidDeduct);
            //remove from bid cart & direct to new page
            $cartDAO->delete($bidObj);
            echo "<meta http-equiv='refresh' content='0;url=student_index.php'>";
            
        }
        
    }
        
        
        
       
    
    

?>