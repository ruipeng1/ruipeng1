<?php
require_once 'include/common.php';
$nav_tab ="";
$nav_tab_url = "#";
$nav_tab_1 = "";
$nav_tab_url_1 = "#";
$nav_tab_2 = "";
$nav_tab_url_2 = "#";
$errors = "";


if ( isset($_GET['errors']) ) {
    $errors = $_GET["errors"];
  
} elseif ( isset($_POST['userid']) && isset($_POST['password']) ) {
    
    $userid = $_POST['userid'];
    $password = $_POST['password'];
    $account = $_POST['type'];
    echo $account;
    // ------------------------------------------ Hashed --------------------------------
    if ($account == 'student') {
        $dao = new StudentDAO();
        $user = $dao->retrieve($userid);
        if ($user != null && $user->authenticate($password)){
            $_SESSION['userid'] = $userid; 
            header("Location: student_index.php");
            return;
        }
        else {
            $errors = 'Incorrect username or password!';
        }
    }
    elseif ($account == 'admin') {
        if ($userid == "admin" && $password == "@Dmin!23"){
            $_SESSION['userid'] = $userid; 
            header("Location: admin_index.php");
            return;
        }
        else {
            $errors = 'Incorrect username or password!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<?=require_once 'include/head.php';?>
<body>
    <?= require_once 'include/nav.php';?>

    <!--background img-->
    <header id="login">
        <img src="resource/image/background.jpg" width="100%" height="100%">
    </header>

    <!-- Page Content -->
    <div class="container">
        <div class="card login col-lg-4">
            <div class="card-body" >
                <div class = "card-title merlion_img"><img src = "merlion.png" width="100%" ></div>
                <h5 class="card-title">Login</h5>
                <p class="card-text">
                    <form action = "login.php" method = "POST">
                        <div class="form-group">
                            <label for="userid1">User ID</label>
                            <input type="text" name="userid" class="form-control" id="userid1" aria-describedby="emailHelp" placeholder="Enter userid" required>
                            <!-- <small id="emailHelp" class="form-text text-muted">For example "abc.123"</small> -->
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" name = "password" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
                        </div>
                        <select name = 'type'>
                            <option value = 'student'>Student</option>
                            <option value = 'admin'>Admin</option>
                        </select>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                    <p style="color:red;"><?=$errors?></p>
                </p>
            </div>
        </div>
        <!-- /.row -->
    </div>
     
    <?php require_once 'include/footer.php'?>
</body>
</html>