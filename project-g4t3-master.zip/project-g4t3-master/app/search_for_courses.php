<?php
require_once "include/protect.php";
require_once "include/common.php";

$dao = new StudentDAO();
$userid = $_SESSION['userid'];
$user = $dao->retrieve($userid);
$name = $user ->getName();
$edollar = $user->getEdollar();
$school = $user->getSchool();
$nav_tab = "Cart";
$nav_tab_url = "cart.php";
$nav_tab_1 = "Logout";
$nav_tab_url_1 = "logout.php";
$nav_tab_2 = "Home";
$nav_tab_url_2 = "student_index.php";

$coursedao = new CourseDAO();
$course_list = $coursedao->retrieveAll();

$sectiondao = new SectionDAO();
$section_list = $sectiondao->retrieveAll();

// ------------------------------------*NEW*----------------------------------------//
$sch_arr=[];
foreach($course_list as $course_obj) {
    $sch=$course_obj->getSchool();
    if (!in_array($sch,$sch_arr)){
        $sch_arr[]=$sch;
    }
}
$sec_num_arr=[];
foreach($section_list as $sec_obj) {
    $sec_num=$sec_obj->getSection();
    if (!in_array($sec_num,$sec_num_arr)){
        $sec_num_arr[]=$sec_num;
    }
}
//----------------------------------------------------------------------------------//

$roundDAO = new RoundnumDAO();
$currentRound = $roundDAO->retrieveall(); 

if (isset($_GET['coursecode']))
{
    $coursecode = $_GET['coursecode'];
    $sort_by_course = $sectiondao->retrieveByCourse($coursecode);
}

if (isset($_GET['school']))
{
    $school = $_GET['school'];
    $sort_by_school = $coursedao->retrieveBySchool($school);
}

if (isset($_GET['coursecode']) && isset($_GET['sectionno'])){
    $coursecode = $_GET['coursecode'];
    $sectionno = $_GET['sectionno'];
    $sort_by_course_section = $sectiondao->retrieve($coursecode,$sectionno);
}

if (isset($_GET['school']) && isset($_GET['coursecode']))
{
    $school = $_GET['school'];
    $coursecode = $_GET['coursecode'];
    $sort_by_school_course = $coursedao->retrieveBySchoolCourse($school,$coursecode);
}

if (isset($_GET['sectionno']))
{
    $sectionno = $_GET['sectionno'];
    $sort_by_section = $sectiondao->retrieveBySection($sectionno);
}
$_SESSION['search_for_courses']='active';

$day = [1 => "Mon", 2 => "Tue", 3 => "Wed", 4 => "Thu", 5 => "Fri", 6=>"Sat",7=>"Sun"];


?>


<!DOCTYPE html>
<html lang="en">
    <?php require_once 'include/head.php'; ?>   
    <body>
        <?= require_once 'include/nav.php'?>
        <form action = "search_for_courses.php" method = "GET"> 
        <div class="container">
            <div class="jumbotron">
                <div class="row">
                    <div style ="text-align:center;">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="student_index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Search</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                
                
                <div class="row">
                    <div class="col">
                        <div class="div-inline">
                            <label style="padding-right:55px;">School</label>
                                <select name = "school" style="width:200px;">
                                <?php
                                //To pre select school for students in round 1
                                    if($currentRound->getRound()==1){
                                        echo "<option value ='$school' selected>$school</option>";

                                //------------------------------*New*--------------------------//
                                    }else{ 
                                        $school_selected="";
                                        if(isset($_GET['school'])){
                                            $school_selected=$_GET['school'];
                                        }
                                        echo "<option value = ''></option>";
                                        foreach ($sch_arr as $sch){
                                            $selected="";
                                            if ($sch==$school_selected){
                                                $selected="selected";
                                            }
                                            echo "<option value = '$sch' $selected>$sch</option>"; 
                                        }
                                    }
                                //--------------------------------------------------------------//
                                    
                                ?>
                                </select>
                        </div>
                        <div class="div-inline">
                            <label style="padding-right:12px;">Course Code</label>
                            <select name = "coursecode" style="width:200px;">
                                <option value = ''></option>
                                <?php
                                $_SESSION['cc']="";
                                foreach($course_list as $course){
                                    if(isset($_GET['coursecode'])){
                                        $_SESSION['cc']=$_GET['coursecode'];
                                    }
                                    echo "<option value = '{$course->getCourse()}'";
                                    if($course->getCourse()==$_SESSION['cc']){
                                        echo "selected";
                                    }
                                    echo ">{$course->getCourse()}</option>";
                                    
                                }
                                ?>
                            </select>   
                        </div>
                        <div class="div-inline">
                            <label style="padding-right:25px;">Section No</label>
                            <select name = "sectionno" style="width:200px;" onchange="">
                            <?php
                                //------------------------------*New*--------------------------//
                                $section_selected="";
                                if(isset($_GET['sectionno'])){
                                    $section_selected=$_GET['sectionno'];
                                }
                                
                                echo "<option value = ''></option>";
                                foreach ($sec_num_arr as $sec_num){
                                    $selected="";
                                    if ($sec_num==$section_selected){
                                        $selected="selected";
                                    }
                                    echo "<option value = '$sec_num' $selected>$sec_num</option>"; 
                                }
                                ?>
                            </select>
                        
                        
                            <button type="submit" name ="Search" value="Search" class="btn btn-secondary btn-sm" style="margin-left:2%;" >Search</button>
                        </div>
                    </div>

                    <div class="col">
                        <p style ="text-align:center; float: left; margin-right: 2%; margin-top:-2%;">You currently have<br/><b style="font-size: 40px; "><?=$edollar?></b><br/>edollars</p> 
                    </div>
                </div><!--end row-->
            </div>
        </form>
                
            
        
            <div class="row">
            <div class="col">
            <form action="cart.php" method="get">
                <h6>COURSE LISTED</h6>
                <?php 
                     printErrors();

                ?>  
                
                <button type="submit" class="btn btn-outline-secondary btn-sm" style="float:right; margin-top:-30px;">Add/View Cart</button>

                <table class='table table-sm table-striped currentBidRow'>
                    <thead>
                        <tr align = 'center'>
                            <td>Course Code</td>
                            <td>Course Title</td>
                            <td>School</td>
                            <td>Section</td>
                            <td>Day</td>
                            <td>Start</td>
                            <td>End</td>
                            <td>Instructor</td>
                        </tr>
                    </thead>
                        
                        <?php
                            //search
                            if (empty($_GET['school']) && empty($_GET['coursecode']) && empty($_GET['sectionno']) && isset($_GET['Search'])){
                                foreach ($section_list as $section){
                                    $courseID = $section->getCourse();
                                        echo "<tr>";
                                        echo "<td><input type='checkbox' name='course_to_cart[]' value={$section->getCourse()},{$section->getSection()}> {$section->getCourse()}</td>";
                                        
                                        $course = $coursedao->retrieve($courseID);
                                        $coursename = $course->getTitle();
                                        echo "<td><center>$coursename</center></td>";
                                        $school= $course->getSchool();
                                        echo "<td><center>$school</center></td>";
                                        echo "<td><center>{$section->getSection()}</center></td>";
                                        echo "<td><center>{$day[$section->getDay()]}</center></td>";
                                        echo "<td><center>{$section->getStart()}</center></td>";
                                        echo "<td><center>{$section->getEnd()}<center></td>";
                                        echo "<td><center>{$section->getInstructor()}<center></td>";
                                        echo "<td><a href = 'viewmore.php?course_section={$section->getCourse()},{$section->getSection()}'>View more</td>";
                                        echo "</tr>";                 
                                }
                            }
                            //all filled
                            elseif (!empty($_GET['school']) && !empty($_GET['sectionno']) && !empty($_GET['coursecode']) && isset($_GET['Search']))
                            {
                                if (empty($sort_by_course_section))
                                {
                                    echo "<tr>";
                                    echo "<td>NO SEARCH RESULTS!</td>";
                                    echo "</tr>";
                                }
                                else
                                {
                                    $courseID = $sort_by_course_section->getCourse();                                       
                                        $course = $coursedao->retrieve($courseID);

                                        $coursename = $course->getTitle();
                                        $school= $course->getSchool();
                                        if ($school != $_GET['school'])
                                        {
                                            echo "<tr>";
                                            echo "<td>NO SEARCH RESULTS!</td>";
                                            echo "</tr>";
                                        }
                                        else
                                        {
                                            echo "<tr>";
                                            echo "<td><input type='checkbox' name='course_to_cart[]' value={$sort_by_course_section->getCourse()},{$sort_by_course_section->getSection()}> {$sort_by_course_section->getCourse()}</td>";
                                            echo "<td><center>$coursename</center></td>";
                                            echo "<td><center>$school</center></td>";
                                            echo "<td><center>{$sort_by_course_section->getSection()}</center></td>";
                                            echo "<td><center>{$day[$sort_by_course_section->getDay()]}</center></td>";
                                            echo "<td><center>{$sort_by_course_section->getStart()}</center></td>";
                                            echo "<td><center>{$sort_by_course_section->getEnd()}<center></td>";
                                            echo "<td><center>{$sort_by_course_section->getInstructor()}<center></td>";
                                            echo "<td><a href = 'viewmore.php?course_section={$sort_by_course_section->getCourse()},{$sort_by_course_section->getSection()}'>View more</td>";
                                            echo "</tr>";
                                        }
                                    
                                }
                            }
                            //only course code
                            elseif (empty($_GET['school']) && empty($_GET['sectionno']) && !empty($_GET['coursecode']) && isset($_GET['Search']))
                            {
                                foreach ($sort_by_course as $result)
                                {
                                    $courseID = $result->getCourse();
                                   
                                        echo "<tr>";
                                        echo "<td><input type='checkbox' name='course_to_cart[]' value={$result->getCourse()},{$result->getSection()}> {$result->getCourse()}</td>";
                                        $course = $coursedao->retrieve($courseID);
                                        $coursename = $course->getTitle();
                                        echo "<td><center>$coursename</center></td>";
                                        $school= $course->getSchool();
                                        echo "<td><center>$school</center></td>";
                                        echo "<td><center>{$result->getSection()}</center></td>";
                                        echo "<td><center>{$day[$result->getDay()]}</center></td>";
                                        echo "<td><center>{$result->getStart()}</center></td>";
                                        echo "<td><center>{$result->getEnd()}<center></td>";
                                        echo "<td><center>{$result->getInstructor()}<center></td>";
                                        echo "<td><a href = 'viewmore.php?course_section={$result->getCourse()},{$result->getSection()}'>View more</td>";
                                        echo "</tr>";
                                    
                                }
                            }
                            //only school
                            elseif (empty($_GET['coursecode']) && empty($_GET['sectionno']) && !empty($_GET['school']) && isset($_GET['Search']))
                            {
                                foreach ($sort_by_school as $result)
                                {
                                    $coursecode = $result->getCourse();
                                    $temp = $sectiondao->retrieveByCourse($coursecode);
                                    foreach ($temp as $result)
                                    {
                                        $courseID = $result->getCourse();
                                        
                                            echo "<tr>";
                                            echo "<td><input type='checkbox' name='course_to_cart[]' value={$result->getCourse()},{$result->getSection()}> {$result->getCourse()}</td>";
                                            $course = $coursedao->retrieve($courseID);
                                            $coursename = $course->getTitle();
                                            echo "<td><center>$coursename</center></td>";
                                            $school= $course->getSchool();
                                            echo "<td><center>$school</center></td>";
                                            echo "<td><center>{$result->getSection()}</center></td>";
                                            echo "<td><center>{$day[$result->getDay()]}</center></td>";
                                            echo "<td><center>{$result->getStart()}</center></td>";
                                            echo "<td><center>{$result->getEnd()}</center></td>";
                                            echo "<td><center>{$result->getInstructor()}</center></td>";
                                            echo "<td><a href = 'viewmore.php?course_section={$result->getCourse()},{$result->getSection()}'>View more</td>";
                                            echo "</tr>";
                                        
                                    }
                                }
                            }
                            //course code n section
                            elseif (empty($_GET['school']) && !empty($_GET['sectionno']) && !empty($_GET['coursecode']) && isset($_GET['Search']))
                            {
                                if (empty($sort_by_course_section))
                                {
                                    echo "<tr>";
                                    echo "<td>NO SEARCH RESULTS!</td>";
                                    echo "</tr>";
                                }
                                else
                                {
                                    $courseID = $sort_by_course_section->getCourse();
                                        echo "<tr>";
                                        echo "<td><input type='checkbox' name='course_to_cart[]' value={$sort_by_course_section->getCourse()},{$sort_by_course_section->getSection()}> {$sort_by_course_section->getCourse()}</td>";
                                    
                                        $course = $coursedao->retrieve($courseID);
                                        $coursename = $course->getTitle();
                                        echo "<td><center>$coursename</center></td>";
                                        $school= $course->getSchool();
                                        echo "<td><center>$school</center></td>";
                                        echo "<td><center>{$sort_by_course_section->getSection()}</center></td>";
                                        echo "<td><center>{$day[$sort_by_course_section->getDay()]}</center></td>";
                                        echo "<td><center>{$sort_by_course_section->getStart()}</center></td>";
                                        echo "<td><center>{$sort_by_course_section->getEnd()}<center></td>";
                                        echo "<td><center>{$sort_by_course_section->getInstructor()}<center></td>";
                                        echo "<td><a href = 'viewmore.php?course_section={$sort_by_course_section->getCourse()},{$sort_by_course_section->getSection()}'>View more</td>";
                                        echo "</tr>";
                                    
                                }
                            }
                            //school and Course code
                            elseif (empty($_GET['section']) && !empty($_GET['school']) && !empty($_GET['coursecode']) && isset($_GET['Search']))
                            {
                                if (empty($sort_by_school_course))
                                {
                                    echo "<tr>";
                                    echo "<td>NO SEARCH RESULTS!</td>";
                                    echo "</tr>";
                                }
                                foreach ($sort_by_school_course as $result)
                                {
                                    $coursecode = $result->getCourse();
                                    $temp = $sectiondao->retrieveByCourse($coursecode);
                                    foreach ($temp as $result)
                                    {
                                        $courseID = $result->getCourse();
                                            echo "<tr>";
                                            echo "<td><input type='checkbox' name='course_to_cart[]' value={$result->getCourse()},{$result->getSection()}> {$result->getCourse()}</td>";
                                        
                                            $course = $coursedao->retrieve($courseID);
                                            $coursename = $course->getTitle();
                                            echo "<td><center>$coursename</center></td>";
                                            $school= $course->getSchool();
                                            echo "<td><center>$school</center></td>";
                                            echo "<td><center>{$result->getSection()}</center></td>";
                                            echo "<td><center>{$day[$result->getDay()]}</center></td>";
                                            echo "<td><center>{$result->getStart()}</center></td>";
                                            echo "<td><center>{$result->getEnd()}</center></td>";
                                            echo "<td><center>{$result->getInstructor()}</center></td>";
                                            echo "<td><a href = 'viewmore.php?course_section={$result->getCourse()},{$result->getSection()}'>View more</td>";
                                            echo "</tr>";
                                       
                                    }
                                }
                            }
                            //only section(or only school & section)
                            elseif (empty($_GET['coursecode']) && isset($_GET['sectionno']) && isset($_GET['Search']))
                            {
                                echo "<p style='color:red;'>Please enter Course Code!</p>";
                              
                            }
                            

                        ?>
                        
                        </form>
                </table>
            </div>
            </div>
            
        </div>
    </body>
</html>

