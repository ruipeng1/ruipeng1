<?php
require_once 'include/common.php';
session_destroy();
header("location: login.php");
exit();

?>