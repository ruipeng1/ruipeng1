<?php
$nav_tab = "logout";
$nav_tab_url = "logout.php";
$nav_tab_1 = "";
$nav_tab_url_1 = "#";
$nav_tab_2 = "Home";
$nav_tab_url_2 = "admin_index.php";

require_once "include/common.php";
require_once "include/protect_admin.php";


echo "<h1>Welcome Admin</h1>";
    
?>

<html>
<?php require_once 'include/head.php';?>
    <body>
    <?php require_once 'include/nav.php'?>

    <div class="container"  >
        <div class="jumbotron">
            <h1 class="display-6" style ="text-align:center;">Welcome, Admin</h1>
            <p class="lead" style ="text-align:center;">Please start/stop round</p>
            <?php 
                $roundDAO = new RoundnumDAO;
                $round = $roundDAO->retrieveAll()->getRound();
                if ($round == "stop1"){
                    $round = "Round 1 Stopped";
                }
                if ($round == "stop2"){
                    $round = "Round 2 Stopped";
                }
                echo "<h1 style = 'text-align:center;'>Round Status: $round </h1>";
            
            ?>
            <div style ="text-align:center;">
            <h3>Round 1</h3>
                <a href="bootstrap.php">
                    <button type="button" class="btn btn-outline-secondary" >Start Bidding Round 1/Bootstrap</button>
                </a>

                <a href = "stop1.php">
                    <button type="button" name="stop1" class="btn btn-outline-secondary" >Stop Bidding Round 1</button>
                </a>
                <br><br>
                <h3>Round 2</h3>
                <a href = "start2.php">
                    <button type="button" class="btn btn-outline-secondary" >Start Bidding Round 2</button>
                </a>

                <a href = "stop2.php">
                    <button type="button" class="btn btn-outline-secondary" >Stop Bidding Round 2</button>
                </a>
            </div> 
            
             
        </div>
    </div>
    </body>
</html>