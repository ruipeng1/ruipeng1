<?php
require_once "include/common.php";
// // require_once "include/protect_admin.php";

// $_SESSION["stop1"]="stop";
$round = "stop1";
$roundDAO = new RoundnumDAO();
$update = $roundDAO->update($round);

//---------------------------------------------Bidding 1 Clearing Logic -------------------------------------------------
$bidDAO = new BidDAO();
$sectionDAO = new SectionDAO();
$enrollDAO=new EnrolledDAO;
$all_sectionArr = $sectionDAO->retrieveAll();
$roundDAO = new RoundnumDAO();
$currRound = $roundDAO->retrieveAll()->getRound();
$each_sect_clearing_bid=[];



if($currRound == "stop1"){

    //store unique course and section with clearing amount
    $each_sect_clearing_bid = [];

    foreach($all_sectionArr as $sectObj){

        $bidObjArr = [];
        

        $sectCourse = $sectObj -> getCourse();
        $sectNo =  $sectObj -> getSection();
        $sectSize = $sectObj -> getSize();
		
        // All the bids of this section
        $bidObjArr  = $bidDAO->orderCourseByDesc($sectCourse, $sectNo);
		
		if(!empty($bidObjArr)){//if there is bids for the section
	
            if(sizeof($bidObjArr) >= $sectSize){//if no. of bids greater than section size
                //Let N be the section size, find the Nth bid 
				$nth_row_bid_obj = $bidObjArr[$sectSize-1];
				
                //get the Nth bid amount, which will be the clearing price
                $nth_row_bid_amt = $nth_row_bid_obj->getAmount();
                $clearingAmt = $nth_row_bid_amt;
          
                //to count how many bids at the clearing price
                $count_no_of_bids_at_clearing_price=0;

				foreach($bidObjArr as $bid){
				    if((($bid->getAmount())==$nth_row_bid_amt)){
				        $count_no_of_bids_at_clearing_price++;
				    }
				}
				
	
                if ($count_no_of_bids_at_clearing_price>1){//if more than one bids at the clearing price, all the bids at this price will fail
                    foreach($bidObjArr as $bid){
						$amt=$bid->getAmount();
                        if($amt>$clearingAmt){//if bidding amount > clearing price ---------> successful
                            $addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'successful');
                            $enrollDAO->add_enrolled($addEnroll);
                            $sectionDAO->updateSize($bid->getCourse(),$bid->getSection(),-1);
							$bidDAO->drop($bid);
						}else{//if bidding amount <= clearing price --------> unsuccessful
							$addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'unsuccessful');
							$enrollDAO->add_enrolled($addEnroll);
							$bidDAO->refund_when_drop($bid->getUserid(), $bid->getAmount());
							$bidDAO->drop($bid);
						}
                    }
                }else{//if only one bid at the clearing price, all the bids >= this price will be successful
					foreach($bidObjArr as $bid){
						$amt=$bid->getAmount();
						
                        if($amt>=$clearingAmt){//if bidding amount > clearing price ---------> successful
                            $addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'successful');
                            $enrollDAO->add_enrolled($addEnroll);
                            $sectionDAO->updateSize($bid->getCourse(),$bid->getSection(),-1);
							$bidDAO->drop($bid);
					    }else{//if bidding amount < clearing price --------> unsuccessful
							$addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'unsuccessful');
							$enrollDAO->add_enrolled($addEnroll);
							$bidDAO->refund_when_drop($bid->getUserid(), $bid->getAmount());
							$bidDAO->drop($bid);
							
						}
                    }

				}

                    
            }else{//if no. of bids less than the section size
                $clearingAmt = 10;
                foreach($bidObjArr as $bid){
                    $addEnroll = new Enrolled($bid->getUserid(),$bid->getCourse(),$bid->getSection(),$bid->getAmount(),$currRound,'successful');
                    $enrollDAO->add_enrolled($addEnroll);
                    $sectionDAO->updateSize($bid->getCourse(),$bid->getSection(),-1);
                    $bidDAO->drop($bid);
                }
            }           
        }
    }
}



?>