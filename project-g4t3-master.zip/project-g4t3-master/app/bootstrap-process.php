<?php
# edit the file included below. the bootstrap logic is there
require_once 'include/bootstrap.php';
require_once "include/protect_admin.php";

echo "<a href='admin_index.php'>Back to Admin Page</a><br><br>";

$result = doBootstrap();
$roundnumDAO = new RoundnumDAO;
$update = $roundnumDAO->update(1);
$bootstrap_status = $result['status'];
echo "<b>Bootstrap Status:</b> $bootstrap_status";
echo "<br><br>";
$bootstrap_messages = $result["num-record-loaded"];
echo "<table border = '1'>
        <tr>
        <td colspan = '2'><b>Number of record loaded</b></td>
        </tr>";
foreach ($bootstrap_messages as $keys => $values){
    foreach ($values as $key => $value){
        echo "<tr><td><b>$key</b></td><td>$value</td></tr>";
    }
}
echo "</table>";
echo "<br><br>";

if ($bootstrap_status == "error"){
    $bootstrap_errors = $result['error'];
    echo "<table border = '1'>
        <tr>
        <th colspan = '3'>Error Messages</th>
        </tr>
        <tr>
        <th >File</th>
        <th >Line</th>
        <th >Message</th>
        </tr>
    ";
    foreach ($bootstrap_errors as $keys => $values){
        echo "<tr>
                <td>{$values['file']}</td>
                <td>{$values['line']}</td>
                <td>";
        foreach ($values['message'] as $msg){
                echo "$msg<br>";
        }
        echo"</td>
        </tr>";
    }
}




?>