
<?php
require_once "../include/common.php";
require_once "../include/protect_json.php";

$courseDAO = new CourseDAO;
$sectionDAO = new SectionDAO;
$studentDAO = new StudentDAO;
$prerequisiteDAO = new PrerequisiteDAO;
$bidDAO = new BidDAO;
$course_completedDAO = new Course_completedDAO;
$enrolled = new EnrolledDAO;
$roundnumDAO = new RoundnumDAO;

$errors = "";

if (!isEmpty($errors))
	{	
        $result = [ 
        "status" => "error"
        ];
    }
else{

$roundnum=$roundnumDAO->retrieveAll()->getRound();
if ($roundnum == 2){
    require_once '../round2_logic.php';
}
//--------------------------------------------------------------course dump------------------------------------------------------------
    $courses = $courseDAO->retrieveAll2();
    $course_dump = [];
    //$keys9 = array_column($courses,'course');
    // array_multisort($keys9,SORT_ASC,$courses);
    foreach ($courses as $course){
        $coursename = $course->getCourse();
        $coursesch = $course->getSchool();
        $coursetitle = $course->getTitle();
        $coursedescription = $course->getDescription();
        $coursedate = $course ->getExam_date();
        $coursedate = str_replace('-','',$coursedate);
        $coursestart = $course ->getExam_start();
        $coursestart = date('Hi', strtotime($coursestart));
        $coursestart = ltrim($coursestart,0);
        $courseend = $course ->getExam_end();
        $courseend = date('Hi', strtotime($courseend));
        $courseend = ltrim($courseend,0);

        $course_dump[] = [
            "course" => $coursename,
            "school" => $coursesch,
            "title" => $coursetitle,
            "description" => $coursedescription,
            "exam date" => $coursedate,
            "exam start" => $coursestart,
            "exam end" => $courseend
        ]; 
    }
//-----------------------------------------------------------section dump----------------------------------------------------------------
    $roundnum=$roundnumDAO->retrieveAll()->getRound();
    $sections = $sectionDAO->retrieveAll2();
    $section_dump = [];
    //$keys10 = array_column($sections,'course');
    //array_multisort($keys10,SORT_ASC,$sections);
    $days = [
        '1' => 'Monday',
        '2' => 'Tuesday',
        '3' => 'Wednesday',
        '4' => 'Thursday',
        '5' => 'Friday',
        '6' => 'Saturday',
        '7' => 'Sunday'
    ];

    foreach ($sections as $section){
        $sectioncourse = $section->getCourse();
        $sectionnum = $section->getSection();
        $sectionday = $days[$section->getDay()];
        $sectionstart = $section->getStart();
        $sectionstart = date('Hi', strtotime($sectionstart));
        $sectionstart = ltrim($sectionstart,0);
        $sectionend = $section->getEnd();
        $sectionend = date('Hi', strtotime($sectionend));
        $sectionend = ltrim($sectionend,0);
        $sectioninstructor = $section->getInstructor();
        $sectionvenue = $section->getVenue();

        if($roundnum!='2'){
            $sectionsize = intval($section->getSize());
        }else{
            $r2_vacancy=$section->getSize();
            $sectionsize=$r2_vacancy + sizeof($enrolled->retrieve_success_enrolled($sectioncourse,$sectionnum,"2"));
            $sectionsize=intval($sectionsize);
        }
       

        $section_dump[] = [
            "course" => $sectioncourse,
            "section" => $sectionnum,
            "day" => $sectionday,
            "start" => $sectionstart,
            "end" => $sectionend,
            "instructor" => $sectioninstructor,
            "venue" => $sectionvenue,
            "size" => $sectionsize
        ]; 
    }
//--------------------------------------------------------------student dump-----------------------------------------------------------
    $students = $studentDAO->retrieveAll2();
    $student_dump = [];
    foreach ($students as $student){
        $studentid = $student->getUserid();
        $studentpw = $student->getPassword();
        $studentname = $student->getName();
        $studentsch = $student->getSchool();
        $studentedollar = floatval($student->getEdollar());
        
        $student_dump[] = [
            "userid" => $studentid,
            "password" => $studentpw,
            "name" => $studentname,
            "school" => $studentsch,
            "edollar" => $studentedollar
        ];
    }
    //var_dump($student_dump);
//-----------------------------------------------------------prerequisite dump------------------------------------------------------------
    $prerequisites = $prerequisiteDAO->retrieveAll2();
    $prerequisite_dump = [];
    // $keys11 = array_column($prerequisites,'course');
    // $keys12 = array_column($prerequisites,'prerequisite');
    // array_multisort($keys11,SORT_ASC,$keys12,SORT_ASC,$prerequisites);
    foreach ($prerequisites as $prerequisite){
        $prerequisitecourse = $prerequisite->getCourse();
        $prerequisiteprerequisite = $prerequisite->getPrequisite();
    
        $prerequisite_dump[] = [
            "course" => $prerequisitecourse,
            "prerequisite" => $prerequisiteprerequisite
        ];
    }

//---------------------------------------------------------bid dump-----------------------------------------------------------------------
    //Only the bid details for the current round should be shown in the bid records. If the current round is round 2, 
    //list the last bid made by each user in each section. If there is no active round, 
    // the bids (whether successful or unsuccessful) for the most recently 
    // concluded round should be shown. The system does not need to maintain a history of bidding results from previous bidding rounds.
    
    // sort by:
    // Order of the course code.
    // order of the section code (S1, S2, S3 ..)
    // Highest bid to Lowest bid
    // username
    $bid_dump = [];
    $roundnum=$roundnumDAO->retrieveAll()->getRound();
    if ($roundnum == "1"||$roundnum == "2"){
        $bids = $bidDAO->retrieveAll2();// sorted when retrieve from database
        
        foreach ($bids as $bid){
            $bidid = $bid->getUserid();
            $bidamount = floatval($bid->getAmount());
            $bidcourse = $bid->getCourse();
            $bidsection = $bid->getSection();
    
            $bid_dump[] = [
                "userid" => $bidid,
                "amount" => $bidamount,
                "course" => $bidcourse,
                "section" => $bidsection
            ];
        }

    }elseif ($roundnum == "stop1"||$roundnum == "stop2"){
        if($roundnum == "stop2"){
            $roundnum='2';
        }
        
        $enrolled_arr=$enrolled->retrieve_round_enrolled1($roundnum);

        //var_dump($enrolled_arr);

        foreach ($enrolled_arr as $enrolled_course){
            $enrolledid = $enrolled_course->getUserid();
            $enrolledcourse = $enrolled_course->getCourse();
            $enrolledsection = $enrolled_course->getSection();
            $enrolledAmount= floatval($enrolled_course-> getAmount());

            $bid_dump[] = [
                "userid" => $enrolledid,
                'amount' => $enrolledAmount,
                "course" => $enrolledcourse,
                "section" => $enrolledsection
            ];
        }


    }
    
    

//-------------------------------------------------completed-course dump---------------------------------------------------------------
    $completed_courses = $course_completedDAO->retrieveAll2();
    $completed_courses_dump = [];
    

    foreach ($completed_courses as $completed_course){
        $completedid = $completed_course->getUserid();
        $completedcode = $completed_course->getCode();
        
        $completed_courses_dump[] = [
            "userid" => $completedid,
            "course" => $completedcode
        ];
    }



//------------------------------------------------section-student dump------------------------------------------------------------------
    $roundnum=$roundnumDAO->retrieveAll()->getRound();
    
    $enrolled_courses_dump = [];
    $enrolled_courses=[];

    if($roundnum=="stop1" || $roundnum=="stop2"){
        $enrolled_courses = $enrolled->retrieve_user_success_enrolled2();
        
    }elseif($roundnum=="2"){
        $enrolled_courses = $enrolled->retrieve_round_succ_enrolled1($roundnum);
    }
    
        foreach ($enrolled_courses as $enrolled_course){
        $enrolledid = $enrolled_course->getUserid();
        $enrolledcourse = $enrolled_course->getCourse();
        $enrolledsection = $enrolled_course->getSection();
        $enrolledAmount=$enrolled_course-> getAmount();
        $enrolled_courses_dump[] = [
            "userid" => $enrolledid,
            "course" => $enrolledcourse,
            "section" => $enrolledsection,
            'amount' => floatval($enrolledAmount)
        ];
    }

  
    $result = [ 
        "status" => "success",
        "course" => $course_dump,
        "section" => $section_dump,
        "student" => $student_dump,
        "prerequisite" => $prerequisite_dump,
        "bid" => $bid_dump,
        "completed-course" => $completed_courses_dump,
        "section-student" => $enrolled_courses_dump
    ];
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_PRESERVE_ZERO_FRACTION);

?>