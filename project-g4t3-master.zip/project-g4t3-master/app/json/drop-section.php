<?php
require_once '../include/common.php';
require_once "../include/protect_json.php";

$studentDAO = new StudentDAO;
$courseDAO = new CourseDAO;
$sectionDAO = new SectionDAO;
$roundnumDAO = new RoundnumDAO;
$enrolledDAO = new EnrolledDAO;

$errors = [];

if (isset($_GET['r'])){
    $array = json_decode($_GET['r'],TRUE);
    $userid = "";
    $course = "";
    $section = "";

    $mandatory_fields = [];
    foreach ($array as $key => $value){
        if ($key == "userid"){
            $userid = $value;
        }
        if ($key == "course"){
            $course = $value;
        }
        if ($key == "section"){
            $section = $value;
        }
        $mandatory_fields[] = $key;
    }

    #check if any mandatory field missing and blanks
    if (!in_array("course",$mandatory_fields)){
        $errors[] = "missing course";
    }
    elseif ($course == ""){
        $errors[] = "blank course";
    }

    if (!in_array("section",$mandatory_fields)){
        $errors[] = "missing section";
    }
    elseif ($section == ""){
        $errors[] = "blank section";
    }
    if (!in_array("userid",$mandatory_fields)){
        $errors[] = "missing userid";
    }
    elseif ($userid == ""){
        $errors[] = "blank userid";
    }


    #if got missing/blank mandatory field
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
    }
    else{
        #check against list of possible errors
        if (empty($courseDAO->retrieve($course))){
            $errors[] = "invalid course";
        }
        else{
            if (empty($sectionDAO->retrieve($course,$section))){
                $errors[] = "invalid section";
            }
        }
        if (empty($studentDAO->retrieve($userid))){
            $errors[] = "invalid userid";
        }
        #check if round has ended
        if ($roundnumDAO->retrieveAll()->getRound() == "stop1" || $roundnumDAO->retrieveAll()->getRound() == "stop2"){
            $errors[] = "round not active";
        }
        $roundnum = $roundnumDAO->retrieveAll()->getRound();
        if ($roundnum == "2"){
            require_once '../round2_logic.php';
        }
        #check if bid exist
        if ($roundnumDAO->retrieveAll()->getRound() != "stop1" || $roundnumDAO->retrieveAll()->getRound() != "stop2"){
            if (!empty($courseDAO->retrieve($course)) && !empty($sectionDAO->retrieve($course,$section)) && !empty($studentDAO->retrieve($userid))){
                    ##if fail to retrieve bid then error = "no such bid" 
                    if (empty($enrolledDAO->retrieve_enrolled($userid,$course,$section))){
                        $errors[] = "no such enrollment record";
                    }
            } 
        }
    }
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
    }
    else{
        #delete enrolled and refund amount 
        if (!empty($enrolledDAO->retrieve_enrolled($userid,$course,$section))){
            $enrolled = $enrolledDAO->retrieve_enrolled($userid,$course,$section);
            $enrolledDAO->drop($enrolled);
            $amount = $enrolled->getAmount();
            $enrolledDAO->refund_when_drop($userid,$amount);
            $result = [ 
                "status" => "success"
            ];
        }
    }
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);
?>