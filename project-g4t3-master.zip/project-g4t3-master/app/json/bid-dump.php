<?php
require_once '../include/common.php';
require_once "../include/protect_json.php";
$bidDAO = new BidDAO;
$roundnumDAO = new RoundnumDAO;
$enrolledDAO = new EnrolledDAO;
$courseDAO = new CourseDAO;
$sectionDAO = new SectionDAO;

$errors = [];

if (isset($_GET['r'])){
    $array = json_decode($_GET['r'],TRUE);
    $course = "";
    $section = "";

    $mandatory_fields = [];

    foreach ($array as $key => $value){
        if ($key == "course"){
            $course = $value;
        }
        if ($key == "section"){
            $section = $value;
        }
        $mandatory_fields[] = $key;
    }

     #check if any mandatory field missing and blanks
    if (!in_array("course",$mandatory_fields)){
        $errors[] = "missing course";
    }
    elseif ($course == ""){
        $errors[] = "blank course";
    }
    if (!in_array("section",$mandatory_fields)){
        $errors[] = "missing section";
    }
    elseif ($section == ""){
        $errors[] = "blank section";
    }

    #if got missing/blank mandatory field
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
    }
    else{
        #check against list of possible errors
        if (empty($courseDAO->retrieve($course))){
            $errors[] = "invalid course";
        }
        else{
            if (empty($sectionDAO->retrieve($course,$section))){
                $errors[] = "invalid section";
            }
        }
    }
    ## check logical validation 
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
    }
    else{
        #include all logical validations
        $roundnum = $roundnumDAO->retrieveAll()->getRound();
        $bid_result = "";
        if ($roundnum == "2"){
            require_once '../round2_logic.php';
        }
        
        #if round still active, then result should be "-"
        if ($roundnum == "1" || $roundnum == "2"){
            $bid_result = "-";
            $all_bids = $bidDAO->orderCourseByDesc2($course,$section);
            $count = 0;
            $total_bid_result = [];
            foreach ($all_bids as $bids){
                $count++;
                $bid_userid = $bids->getUserid();
                $bid_amount = floatval($bids->getAmount());
            
                $total_bid_result[] = [
                    "row" => $count,
                    "userid" => $bid_userid,
                    "amount" => $bid_amount,
                    "result" => $bid_result
                ]; 
            }
            $result = [
                "status" => "success",
                "bids" => $total_bid_result
            ];
        }
        else{
            #need to cross check between those that bidded and those that actually got enrolled
            //$all_bids = $bidDAO->retrieve_bid_course_section($course,$section);
            if ($roundnum == "stop2" ){
                $roundnum='2';

            }
            $all_enrolled = $enrolledDAO->retrieve_enrolled_desc($course,$section,$roundnum);
            $count = 0;
            $total_bid_result = [];
            $enrolled_userid = [];

            foreach ($all_enrolled as $enrolled){
                $enrolled_userid = $enrolled->getUserid();
            // }
            // foreach ($all_bids as $bids){
                $count++;
                // $bid_userid = $bids->getUserid();
                $bid_amount = floatval($enrolled->getAmount());
                if ($enrolled->getStat()=='unsuccessful'){
                    $bid_result = "out";
                }   
                else{
                    $bid_result = "in";
                }
                $total_bid_result[] = [
                    "row" => $count,
                    "userid" => $enrolled_userid,
                    "amount" => $bid_amount,
                    "result" => $bid_result
                ]; 
            }
            $result = [
                "status" => "success",
                "bids" => $total_bid_result
            ];
        }
    }
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_PRESERVE_ZERO_FRACTION);
?>

