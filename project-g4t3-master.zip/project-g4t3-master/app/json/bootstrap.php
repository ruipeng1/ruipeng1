<?php
require_once '../include/bootstrap.php';
require_once "../include/protect_json.php";
# complete bootstrap

$result = doBootstrap();
$roundnumDAO = new RoundnumDAO;
$update = $roundnumDAO->update(1);

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);





?>

