<?php
require_once '../include/common.php';
require_once "../include/protect_json.php";

$studentDAO = new StudentDAO;
$courseDAO = new CourseDAO;
$sectionDAO = new SectionDAO;
$roundDAO = new RoundnumDAO;
$bidDAO = new BidDAO;
$enrolledDAO = new EnrolledDAO;
$course_completedDAO = new Course_completedDAO;

$errors = [];

if (isset($_GET['r'])){
    $array = json_decode($_GET['r'],TRUE);
    $userid = "";
    $amount = "";
    $course = "";
    $section = "";

    $mandatory_fields = [];
    foreach ($array as $key => $value){
        if ($key == "userid"){
            $userid = $value;
        }
        if ($key == "amount"){
            $amount = $value;
        }
        if ($key == "course"){
            $course = $value;
        }
        if ($key == "section"){
            $section = $value;
        }
        $mandatory_fields[] = $key;
    }

//------------------------------------check if any mandatory field missing and blanks---------------------------------------------------//
    
    // *new*
    //correct sequence: amount, course, section, userid
    // amount 
    if (!in_array("amount",$mandatory_fields)){
        $errors[] = "missing amount";
    }
    elseif ($amount == ""){
        $errors[] = "blank amount";
    }
    
    // course
    if (!in_array("course",$mandatory_fields)){
        $errors[] = "missing course";
    }
    elseif ($course == ""){
        $errors[] = "blank course";
    }

    // section
    if (!in_array("section",$mandatory_fields)){
        $errors[] = "missing section";
    }
    elseif ($section == ""){
        $errors[] = "blank section";
    }

    // userid
    if (!in_array("userid",$mandatory_fields)){
        $errors[] = "missing userid";
    }
    elseif ($userid == ""){
        $errors[] = "blank userid";
    }



    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
        header('Content-Type: application/json');
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit;
    }
//----------------------------------------------------------input validations-----------------------------------------------------------//
    else{// if no field is blank or missing, do validations

        if (!is_numeric($amount) || $amount < 10  || !isNonNegative($amount)){  //*new* check for 2 decimal 
            $errors[] = "invalid amount";
        }

        if (empty($courseDAO->retrieve($course))){
            $errors[] = "invalid course";
        }
        else{
            if (empty($sectionDAO->retrieve($course,$section))){
                $errors[] = "invalid section";
            }
        }

        if (empty($studentDAO->retrieve($userid))){
            $errors[] = "invalid userid";
        }
    }
    

    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
        header('Content-Type: application/json');
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit;
    }
//---------------------------------------------------------check logical validation---------------------------------------------------------//
    else{// if no field is blank or missing or invalid, do logical validations

        $currRound = $roundDAO->retrieveAll()->getRound();
        // if round ended, return only this error
        if ($currRound == "stop1" || $currRound == "stop2"){
            $errors[] = "round ended";
            $result = [ 
                "status" => "error",
                "message" => $errors
            ];
            header('Content-Type: application/json');
            echo json_encode($result, JSON_PRETTY_PRINT);
            exit;
        }
        else{
            //invoke Round 2 logic every time load the file, to update the enrollments
            if ($currRound == "2"){
                require_once '../round2_logic.php';
            }

            if (empty($bidDAO->retrieve_bid_course($userid,$course))){//if this is a new bid 
                $bid = new Bid ($userid, $amount, $course,$section); 
                #logical validations before we can add new bid

                # check if course enrolled
                if (!empty($enrolledDAO->retrieve_enrolled_course($userid,$course))){//retrieve_enrolled_course($userid,$course)
                    if ($enrolledDAO->retrieve_enrolled_course($userid,$course)->getStat() == "successful" ){
                        $errors[] = "course enrolled";
                    }
                }
                
                # check for sufficient e$
                $student = $studentDAO->retrieve($userid);
                $student_edollar = $student->getEdollar();
                    
                if ($student_edollar < $amount){
                    $errors[] = "insufficient e$";
                }
                
                # information on the current bidded course and
                $curr_section_time_start = intval($sectionDAO ->retrieve($course, $section)->getStart());
                $curr_section_time_end = intval($sectionDAO ->retrieve($course, $section)->getEnd());

                $curr_exam_time_start = intval($courseDAO ->retrieve($course)->getExam_start());
                $curr_exam_time_end = intval($courseDAO ->retrieve($course)->getExam_end());

                $curr_exam_date = $courseDAO ->retrieve($course)->getExam_date();
                $curr_section_day = $sectionDAO ->retrieve($course, $section)->getDay();

                
                // to retrieve all bids 
                $all_user_bids = $bidDAO->retrieve($userid);
                //*new* to retrieve successful enrolled bids in round 2 also
                if ($currRound == "2"){
                    $enrolled_arr=[];
                    $enrolled_arr=$enrolledDAO->retrieve_user_success_enrolled($userid);
                    
                    if ( $enrolled_arr!=[] ){
                        foreach($enrolled_arr as $obj){
                            $all_user_bids[]= new Bid ($userid, $obj->getAmount(), $obj->getCourse(), $obj->getSection());
                        }
                    }
                }
                
                foreach($all_user_bids as $user_bid){
                    $exist_course = $user_bid->getCourse();
                    $exist_section = $user_bid->getSection();
                    
                    $section_time_start = intval($sectionDAO ->retrieve($exist_course, $exist_section)->getStart());
                    $section_time_end = intval($sectionDAO ->retrieve($exist_course, $exist_section)->getEnd());
                    $section_day = ($sectionDAO ->retrieve($exist_course, $exist_section)->getDay());

                    $exam_time_start = intval($courseDAO ->retrieve($exist_course)->getExam_start());
                    $exam_time_end = intval($courseDAO ->retrieve($exist_course)->getExam_end());
                    $exam_date = $courseDAO ->retrieve($exist_course)->getExam_date();

                    if(checkTimeClash2($curr_section_time_start,$curr_section_time_end, $section_time_start,$section_time_end) && $curr_section_day == $section_day ){
                        if(!in_array("class timetable clash", $errors)){
                            $errors[] = "class timetable clash";
                        }
                    }
                    if (checkTimeClash2($curr_exam_time_start,$curr_exam_time_end, $exam_time_start,$exam_time_end) && $curr_exam_date ==$exam_date){
                        if(!in_array("exam timetable clash", $errors)){
                            $errors[] = "exam timetable clash";	
                        }
                        			
                    }

                }

                

                //----------
                # check if course completed
                if (checkCourseCompleted($userid, $course)){
                    $errors[] = "course completed";
                }

                # check if prereq done
                if(!empty(checkPreReqExist($course))){
                    $prereqCourses = checkPreReqExist($course);

                    for($i = 0; $i<count($prereqCourses);$i++){
                        if (checkCourseCompleted($userid, $prereqCourses[$i])==false){
                            $errors[] = "incomplete prerequisites";
                        }
                    }
                }


                # check if section limit reached
                $success_bid_Arr = [];
                $success_bid_Arr = $bidDAO->retrieve($userid);
                $countEnrolled = 0;
                $success_enrolled = $enrolledDAO-> retrieve_user_success_enrolled($userid);
                if($success_enrolled){
                    $countEnrolled = count($success_enrolled);
                    
                }

                // echo $countEnrolled;
                if(!empty($success_bid_Arr)){
                    if(count($success_bid_Arr) + $countEnrolled + 1 > 5){ //change the value to 5
                        $errors[] = "section limit reached";
                    }
                }

                # if round 1, check if own school course
                if($currRound == "1"){					
                    $student_sch = $studentDAO->retrieve($userid)->getSchool();
                    $courses_by_school = getCoursesBySch($student_sch);
                    if (in_array($course, $courses_by_school) == false){
                        $errors[] = "not own school course";
                    }
                }
                # check if there is vacancy
                        # not done
                if($currRound == "1"){
                    $size = $sectionDAO->retrieve($course,$section)->getSize();
                    if ($size == 0){
                        $errors[] = "no vacancy";
                    }
                }elseif($currRound == "2"){
                    $size = $sectionDAO->retrieve($course,$section)->getSize();
                    $size_after_round1=$size+sizeof($enrolledDAO->retrieve_success_enrolled($course,$section,"2"));
                    if ($size_after_round1 == 0){
                        $errors[] = "no vacancy";
                    }
                }

                # check if bid too low 
                # need to wait for min bid variable to be ready 

                
                if ($currRound == '2'){

                    $minbidDAO = new minBidDAO;

                    if ($minbidDAO->retrieve_bid($course,$section)!=[]){
                        $min_bid = $minbidDAO->retrieve_bid($course,$section)->getedollar();
                     }
                    //else{
                    //     $min_bid=10;
                    // }

                    if ($amount < $min_bid){
                        $errors[] = "bid too low";
                    }
                }

                #if not error then add
                if (isEmpty($errors)){
                    if($bidDAO->add($bid)){
                        $bidDAO->deduct_when_add($bid);
                    }
                }
            }
        else{
            $bid = new Bid ($userid, $amount, $course, $section); 
            #logical validations before we can update
            $current = $bidDAO->retrieve_bid_course($userid,$course);//retrieve_bid_course($userid,$course)
            $curr_amt = $current->getAmount();
            $currRound = $roundDAO->retrieveAll()->getRound();
            
            if ($currRound == "stop1" || $currRound == "stop2"){
                $errors[] = "round ended";
                $result = [ 
                    "status" => "error",
                    "message" => $errors
                ];
                header('Content-Type: application/json');
                echo json_encode($result, JSON_PRETTY_PRINT);
                exit;
            }
            else{
                if ($currRound == 2){
                    $minbidDAO = new minBidDAO;
                    if ($minbidDAO->retrieve_bid($course,$section)!=[]){
                        $min_bid = $minbidDAO->retrieve_bid($course,$section)->getedollar();
                    }else{
                        $min_bid=10;
                    }

                    if ($amount < $min_bid){
                        $errors[] = "bid too low";
                    }
            }
			
			//--------------------------Process logic validation---------------------
			
           

				//----students are allowed to bid for modules from their own school--
				if($currRound == "1"){					
					$student_sch = $studentDAO->retrieve($userid)->getSchool();
					$courses_by_school = getCoursesBySch($student_sch);
					if (in_array($course, $courses_by_school) == false){
						$errors[] = "not own school course";
					}
				}
                // not enough edollar 
                
                // since it is an update, you should drop the bid first and refund the edollar

                $student = $studentDAO->retrieve($userid);
                $student_edollar = $student->getEdollar();
                
                if ($curr_amt + $student_edollar < $amount ){
                    $errors[] = "insufficient e$";
                }
                
                // check if enrolled
               
                
                
            }
                
                if (isEmpty($errors)){
                    $bidDAO->refund_when_drop($userid,$curr_amt);
                    $bidDAO->update2($bid);
                    $bidDAO->deduct_when_add($bid);
                }
        }
        
    }
}   
}

if ($currRound == "2"){
    require_once '../round2_logic.php';
}


// To sort the logical validation errors ascendingly
sort($errors);

if (!isEmpty($errors))
	{	
		$result = [ 
            "status" => "error",
            "message" => $errors
            
        ];
	}

	else
	{	
		$result = [ 
            "status" => "success"
        ];
    }
    

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);


?>