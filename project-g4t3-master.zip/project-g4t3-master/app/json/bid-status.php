<?php
require_once '../include/common.php';
require_once "../include/protect_json.php";

$studentDAO = new StudentDAO;
$courseDAO = new CourseDAO;
$sectionDAO = new SectionDAO;
$roundDAO = new RoundnumDAO;
$bidDAO = new BidDAO;
$enrolledDAO = new EnrolledDAO;
$course_completedDAO = new Course_completedDAO;
$minbidDAO=new minBidDAO;

$errors = [];

if (isset($_GET['r'])){
    $array = json_decode($_GET['r'],TRUE);
    $course = "";
    $section = "";

    $mandatory_fields = [];

    foreach ($array as $key => $value){
        if ($key == "course"){
            $course = $value;
        }
        if ($key == "section"){
            $section = $value;
        }
        $mandatory_fields[] = $key;
    }

//----------------------------------------------missing and blanks check-------------------------------------------------------------------------
    if (!in_array("course",$mandatory_fields)){
        $errors[] = "missing course";
    }elseif ($course == ""){
        $errors[] = "blank course";
    }

    if (!in_array("section",$mandatory_fields)){
        $errors[] = "missing section";
    }elseif ($section == ""){
        $errors[] = "blank section";
    }

    //if got missing/blank mandatory field, dump errors and exit
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
        header('Content-Type: application/json');
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit;
    }
//-----------------------------------------------------Common Validation----------------------------------------------------------------
    else{
        #check against list of possible errors
        if (empty($courseDAO->retrieve($course))){
            $errors[] = "invalid course";
        }
        else{
            if (empty($sectionDAO->retrieve($course,$section))){
                $errors[] = "invalid section";
            }
        }
    }
    // if got invalid, dump errors and exit
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
        header('Content-Type: application/json');
        echo json_encode($result, JSON_PRETTY_PRINT);
        exit;
    }
//-----------------------------------------------------Logical Validation----------------------------------------------------------------
    else{
        $round = $roundDAO->retrieveAll()->getRound();
//----------------------------------------------------------Round 1-------------------------------------------------------------        
// During round 1:
// Vacancy: the total available seats as all the bids are still pending.
// Minimum bid price: when #bid is less than the #vacancy, report the lowest bid amount. Otherwise, set 
// the price as the clearing price. When there is no bid made, the minimum bid price will be 10.0 dollars.
// Bids: report (userid, bid amount, e-dollar balance, status) for all the bids made so far during round 1. Status should be "pending".
// Balance: follow the round 1 logic.    

        if ($round=="1" ){
            // Vacancy: the total available seats as all the bids are still pending
            $vacancy=$sectionDAO->retrieve($course,$section)->getSize();
            // To get all the bids for this section

            $bidObjArr = $bidDAO->orderCourseByDesc2($course,$section);
            // if there is bids for the section
            if(!empty($bidObjArr)){
                if(sizeof($bidObjArr) < $vacancy ){// when #bid is less than the #vacancy, report the lowest bid amount
                    $min_price=$bidObjArr[sizeof($bidObjArr)-1]->getAmount();
                }
                else{// when #bid is >= the #vacancy, set the price as the clearing price
                    $min_price=$bidObjArr[$vacancy-1]->getAmount();
                }
            }
            // When 0 bid made, the minimum bid price will be 10.0 dollars
            else{
                $min_price=10.0;
            }

            // to dump all the bids
            $bids=[];
            foreach($bidObjArr as $bid_obj){
                $userid=$bid_obj->getUserid();
                $bid=[
                    "userid"=> $userid,
                    "amount"=> floatval($bid_obj->getAmount()),
                    "balance"=> floatval($studentDAO->retrieve($userid)->getEdollar()), 
                    "status"=> "pending"
                ];
                $bids[]=$bid;
            }

            $result=[
                "status" => "success",
                "vacancy"=> intval($vacancy),
                "min-bid-amount"=>floatval($min_price),
                "students"=>$bids
            ];


        }
//----------------------------------------------------------Round stop1-------------------------------------------------------------
        elseif ($round=="stop1" ){
//After Round 1 ended (and before round 2 is started):
//Vacancy: (the total available seats) - (number of successful bid during round 1).
//Minimum bid price: report the lowest successful bid. If no bid made (or no successful bid) during round 1, the value will be 10.0 dollars.
//Bids: report (userid, bid amount, e-dollor balance, status) for all the bids. Status should be either "success" or "fail" according to the round 1 clearing logic.
//Balance: follow the clearing round 1 logic.

            $vacancy= $sectionDAO->retrieve($course,$section)->getSize();
            // To get all the bids for this section
            $enrolled_arr = $enrolledDAO->retrieve_enrolled_desc($course,$section,$round);
            $enrolled_success_arr = $enrolledDAO->retrieve_enrolled_succ_desc($course,$section,$round);
            // if there is bids for the section
            if(!empty($enrolled_arr)){//report the lowest successful bid price
                $min_price=$enrolled_success_arr[sizeof($enrolled_success_arr)-1]->getAmount();
            }
            // When 0 bid made, the minimum bid price will be 10.0 dollars
            else{
                $min_price=10.0;
            }

            // to dump all the bids
            $bids=[];
            foreach($enrolled_arr as $enrolled_obj){
                $userid=$enrolled_obj->getUserid();
                $stat=$enrolled_obj->getStat();
                if ($stat=="successful"){
                    $status="success";
                }else{
                    $status="fail";
                }
                $bid=[
                    "userid"=> $userid,
                    "amount"=> floatval($enrolled_obj->getAmount()),
                    "balance"=> floatval($studentDAO->retrieve($userid)->getEdollar()), 
                    "status"=> $status
                ];
                $bids[]=$bid;
            }

            $result=[
                "status" => "success",
                "vacancy"=> intval($vacancy),
                "min-bid-amount"=>floatval($min_price),
                "students"=>$bids
            ];

        }
//----------------------------------------------------------Round 2-------------------------------------------------------------------
        elseif ($round=="2" ){
// During Round 2:
// Vacancy: follow the round 2 logic. (put the total available vacancies as the round is not over)
// Minimum bid price: follow the round 2 logic.
// Bids: report (userid, bid amount, e-dollor balance, status) for all the bids made during round 2. Status should be either "success" or "fail" reflecting the real-time bidding status.
// Balance: follow the round 2 logic.
            require_once '../round2_logic.php';

            $size= $sectionDAO->retrieve($course,$section)->getSize();//this is the round 2 dynamic vacancy(if success bids enrolled during R2)
            $size_after_round1=$size+sizeof($enrolledDAO->retrieve_success_enrolled($course,$section,"2"));//vacancy after round 1 
            $vacancy=$size_after_round1;
            
            $min_price=$minbidDAO->retrieve_bid($course,$section)->getedollar();

            // To get all the bids for this section
            $enrolled_arr = $enrolledDAO->retrieve_enrolled_desc($course,$section,$round);

            // if there is bids for the section, dump all the bids
            $bids=[];
            if(!empty($enrolled_arr)){
                foreach($enrolled_arr as $enrolled_obj){
                    $userid=$enrolled_obj->getUserid();
                    $stat=$enrolled_obj->getStat();
                    if ($stat=="successful"){
                        $status="success";
                    }else{
                        $status="fail";
                    }
                    $bid=[
                        "userid"=> $userid,
                        "amount"=> floatval($enrolled_obj->getAmount()),
                        "balance"=> floatval($studentDAO->retrieve($userid)->getEdollar()), 
                        "status"=> $status
                    ];
                    $bids[]=$bid;
                }
            }
            
            
            $result=[
                "status" => "success",
                "vacancy"=> intval($vacancy),
                "min-bid-amount"=>floatval($min_price),
                "students"=>$bids
            ];

        }
//----------------------------------------------------------Round stop2-------------------------------------------------------------------
        elseif ($round=="stop2" ){
// After round 2 is closed:
// Vacancy: (the total available seats) - (number of successfully enrolled students in round 1 and 2).
// Minimum bid price: the minimum successful bid amount during round 2. If there was no bid made (or no successful bid) during round 2, the value will be 10.0 dollars.
// Bids: report (userid, bid amount, e-dollor balance, status) for all the successful bids made in round 1 and 2. Do not include failed bids.
// Balance: the e-dollor left after deducting all successful bid amounts in round 1 and 2.
            $vacancy= $sectionDAO->retrieve($course,$section)->getSize();
            // To get all the R2 bids for this section
            $enrolled_arr = $enrolledDAO->retrieve_enrolled_desc($course,$section,"2");
            // To get all the successful R2 bids in for this section
            $r2_enrolled_success_arr = $enrolledDAO->retrieve_enrolled_succ_desc($course,$section,"2");
            //To get all the successful bids(R1 & R2)in for this section
            $all_enrolled_success_arr = $enrolledDAO->retrieve_allround_success($course,$section);

            if(empty($enrolled_arr)||empty($r2_enrolled_success_arr)){//If no bid made (or no successful bid) in r2, min price 10.0 
                $min_price=10.0;
            }
            else if(!empty($enrolled_arr)){//report the lowest successful bid price
                $min_price= $r2_enrolled_success_arr[sizeof( $r2_enrolled_success_arr)-1]->getAmount();
            }
            
            // to dump all the bids
            $bids=[];
            if(!empty($all_enrolled_success_arr)){
                foreach($all_enrolled_success_arr as $enrolled_obj){
                    $userid=$enrolled_obj->getUserid();
                    $stat=$enrolled_obj->getStat();
                    if ($stat=="successful"){
                        $status="success";
                    }else{
                        $status="fail";
                    }
                    $bid=[
                        "userid"=> $userid,
                        "amount"=> floatval($enrolled_obj->getAmount()),
                        "balance"=> floatval($studentDAO->retrieve($userid)->getEdollar()), 
                        "status"=> $status
                    ];
                    $bids[]=$bid;
                }
            }
            

            $result=[
                "status" => "success",
                "vacancy"=> intval($vacancy),
                "min-bid-amount"=>floatval($min_price),
                "students"=>$bids
            ];


        }
    }
}



header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_PRESERVE_ZERO_FRACTION);

?>