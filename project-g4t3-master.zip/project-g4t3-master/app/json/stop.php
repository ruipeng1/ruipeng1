<?php
require_once '../include/common.php';
require_once "../include/protect_json.php";

$roundnumDAO = new RoundnumDAO;
$round = $roundnumDAO->retrieveAll();
$roundnum = $round->getRound();

if ($roundnum == 1){

    require_once '../stop1_logic.php';
    $result = [ 
        "status" => "success",
    ];


}

elseif ($roundnum == 2){
    require_once '../round2_logic.php';
    $update = $roundnumDAO->update("stop2");
    require_once '../stop2_logic.php';
    
    $result = [ 
        "status" => "success",
    ];
}
else{
    $result = [ 
        "status" => "error",
        "message" => [
            "round already ended"
        ]
    ];
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);

?>