<?php
require_once '../include/common.php';
require_once '../include/bootstrap.php';
require_once "../include/protect_json.php";

$roundnumDAO = new RoundnumDAO;
$round = $roundnumDAO->retrieveAll();
$roundnum = $round->getRound();

if ($roundnum == 1){
    $result = [ 
        "status" => "success",
        "round" => 1
    ];
}

elseif ($roundnum == "stop1"){
    $update = $roundnumDAO->update("2");
    require_once '../round2_logic.php';
    $result = [ 
        "status" => "success",
        "round" => 2
    ];
}

elseif ($roundnum == "stop2"){
    $result = [ 
        "status" => "error",
        "message" => [
            "round 2 ended"
        ]
    ];
}


header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);

?>