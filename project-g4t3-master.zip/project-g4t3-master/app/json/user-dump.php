<?php
require_once '../include/common.php';
require_once "../include/protect_json.php";
$studentDAO = new StudentDAO;
$roundnumDAO = new RoundnumDAO;


$errors = [];

if (isset($_GET['r'])){
    $array = json_decode($_GET['r'],TRUE);
    $userid = "";
    $mandatory_fields = [];
    foreach ($array as $key => $value){
        if ($key == "userid"){
            $userid = $value;
        }
        $mandatory_fields[] = $key;
    }

     #check if any mandatory field missing and blanks
    if (!in_array("userid",$mandatory_fields)){
        $errors[] = "missing userid";
    }
    elseif ($userid == ""){
        $errors[] = "blank userid";
    }

    #if got missing/blank mandatory field
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
    }
    else{
        #check against list of possible errors
        if (empty($studentDAO->retrieve($userid))){
            $errors[] = "invalid userid";
        }
    }
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
    }
    else{
        $roundnum=$roundnumDAO->retrieveAll()->getRound();
        if ($roundnum == 2){
            require_once '../round2_logic.php';
        }
        $student = $studentDAO->retrieve($userid);
        $studentid = $student->getUserid();
        $studentpw = $student->getPassword();
        $studentname = $student->getName();
        $studentsch = $student->getSchool();
        $studentedollar = round(floatval($student->getEdollar()),2);
        $result = [
            "status" => "success",
            "userid" => $studentid,
            "password" => $studentpw,
            "name" => $studentname,
            "school" => $studentsch,
            "edollar" => $studentedollar
        ];
        }
    }
header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_PRESERVE_ZERO_FRACTION);
?>


