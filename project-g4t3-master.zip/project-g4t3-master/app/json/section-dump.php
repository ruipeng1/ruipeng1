<?php
require_once '../include/common.php';
require_once "../include/protect_json.php";
$bidDAO = new BidDAO;
$roundnumDAO = new RoundnumDAO;
$enrolledDAO = new EnrolledDAO;
$courseDAO = new CourseDAO;
$sectionDAO = new SectionDAO;

$errors = [];

if (isset($_GET['r'])){
    $array = json_decode($_GET['r'],TRUE);
    $course = "";
    $section = "";

    $mandatory_fields = [];

    foreach ($array as $key => $value){
        if ($key == "course"){
            $course = $value;
        }
        if ($key == "section"){
            $section = $value;
        }
        $mandatory_fields[] = $key;
    }

     #check if any mandatory field missing and blanks
    if (!in_array("course",$mandatory_fields)){
        $errors[] = "missing course";
    }
    elseif ($course == ""){
        $errors[] = "blank course";
    }
    if (!in_array("section",$mandatory_fields)){
        $errors[] = "missing section";
    }
    elseif ($section == ""){
        $errors[] = "blank section";
    }

    #if got missing/blank mandatory field
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
    }
    else{
        #check against list of possible errors
        if (empty($courseDAO->retrieve($course))){
            $errors[] = "invalid course";
        }
        else{
            if (empty($sectionDAO->retrieve($course,$section))){
                $errors[] = "invalid section";
            }
        }
    }
    ## check logical validation 
    if (!isEmpty($errors)){
        $result = [ 
            "status" => "error",
            "message" => $errors
        ];
    }
    else{
        #include all logical validations
        $roundnum = $roundnumDAO->retrieveAll()->getRound();
        #if round 1, then nothing to dump cause no one enrolled yet 
        if ($roundnum == "1"){
            $result = [ 
                "status" => "success",
                "students" => []
            ];
        }
        elseif ($roundnum == "2" || $roundnum == "stop1"){
            #return students that got bidded successfully in round 1
            if ($roundnum == 2){
                require_once '../round2_logic.php';
            }
            $all_enrolled = $enrolledDAO->retrieve_enrolled_succ_desc($course,$section,"stop1");
            $students = [];
            foreach ($all_enrolled as $enrolled){
                $enrolled_userid = $enrolled->getUserid();
                $enrolled_amount = floatval($enrolled->getAmount());
                $students[] = [
                    "userid" => $enrolled_userid,
                    "amount" => floatval($enrolled_amount)
                ];
            }
            sort($students);
            $result = [
                "status" => "success",
                "students" => $students
            ];
        }
        elseif ($roundnum == "stop2"){
            #return all enrolled students who bidded successfully in round 1 and 2
            $all_enrolled = $enrolledDAO->retrieve_allround_success($course,$section);
            $students = [];
            foreach ($all_enrolled as $enrolled){
                $enrolled_userid = $enrolled->getUserid();
                $enrolled_amount = $enrolled->getAmount();
                $students[] = [
                    "userid" => $enrolled_userid,
                    "amount" => floatval($enrolled_amount)
                ];
            }
            sort($students);
            $result = [
                "status" => "success",
                "students" => $students
            ];
        }
    }
}

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT | JSON_PRESERVE_ZERO_FRACTION);
?>

