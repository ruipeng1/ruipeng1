<?php

class Roundnum{
    // property declaration
    public $roundnum; 
    
    public function __construct($roundnum = "") {
        $this->roundnum = $roundnum;

    }
    
    public function getRound(){
        return $this->roundnum;
    }

    public function setRound($NewRoundnum){
        $this->roundnum = $NewRoundnum;
    }
}

?>