
<?php
class Course{
    public $course;
    public $school;
    public $title;
    public $description;
    public $exam_date;
    public $exam_start;
    public $exam_end;

    function __construct($course,$school,$title,$description,$exam_date,$exam_start,$exam_end){
        $this->course = $course;
        $this->school = $school;
        $this->title =$title;
        $this->description=$description;
        $this->exam_date=$exam_date;
        $this->exam_start=$exam_start;
        $this->exam_end=$exam_end;  
    }

    function getCourse(){
        return  $this->course ;
    }

    function getSchool(){
        return  $this->school ;
    }

    function getTitle(){
        return  $this->title ;
    }

    function getDescription(){
        return  $this->description ;
    }
    
    function getExam_date(){
        return  $this->exam_date ;
    }

    function getExam_start(){
        return  $this->exam_start ;
    }

    function getExam_end(){
        return  $this->exam_end ;
    }


}



?>