<?php
$adminid = $_SESSION['userid'];
if($adminid != "admin"){
    header ("Location: login.php?errors=You do not have access.");
    exit;
}
?>