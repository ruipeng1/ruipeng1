<?php
class Bid_in_cart{
    public $userid;
    public $course;
    public $section;
    
    public function __construct($userid= '',$course= '',$section= ''){
        $this->userid = $userid;
        $this->course = $course;
        $this->section = $section;
    }

    public function getUserid(){
        return $this->userid;
    }

    public function getCourse(){
        return $this->course;
    }

    public function getSection(){
        return $this->section;
    }
}
?>