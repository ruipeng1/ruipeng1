<?php

class Bid_in_cartDAO{
    //this will retrieve the all the bids in the cart
    public  function retrieve($userid) {
        $sql = 'select * from bid_in_cart where userid=:userid';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->execute();

        $results = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Bid_in_cart($row['userid'], $row['course'], $row["section"]);
        }
        return $results;
        
    }

    // When add course into cart---- insert a row to bid_in_cart table
    public function add_to_cart($bid_in_cart) {
        $sql = 'INSERT INTO bid_in_cart (userid, course, section) VALUES (:userid, :course, :section)';
        
        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        $stmt->bindParam(':userid', $bid_in_cart->userid, PDO::PARAM_STR);
        $stmt->bindParam(':course', $bid_in_cart->course, PDO::PARAM_STR);
        $stmt->bindParam(':section',$bid_in_cart->section, PDO::PARAM_STR);
        
        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;
    }

   

    // When delete course from cart--- delete a row from bid_in_cart table
    public function delete($bid_in_cart) {
        
        $sql='DELETE FROM bid_in_cart WHERE userid = :userid and course=:course and section=:section' ;

        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        
        $stmt->bindParam(':userid', $bid_in_cart->userid, PDO::PARAM_STR);
        $stmt->bindParam(':course', $bid_in_cart->course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $bid_in_cart->section, PDO::PARAM_STR);
        
        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;

    }


    
    public function removeAll() {
        $sql = 'TRUNCATE TABLE bid_in_cart';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
        $stmt = $conn->prepare($sql);
        
        $stmt->execute();
        $count = $stmt->rowCount();
    }

   
}
?>   