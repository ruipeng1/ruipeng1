<?php
class minBid{
    
    public $course;
    public $section;
    public $edollar;
    
    public function __construct($course= '',$section= '',$edollar= ''){
        $this->course = $course;
        $this->section = $section;
        $this->edollar = $edollar;
    }

    

    public function getedollar(){
        return $this->edollar;
    }

    public function getCourse(){
        return $this->course;
    }

    public function getSection(){
        return $this->section;
    }
}
?>