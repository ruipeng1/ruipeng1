<?php

class EnrolledDAO{
    //retrieve enrolled from specific course and section
    public function retrieve_enrolled_course_section($course,$section) {
        $sql = 'select * from enrolled where course=:course and section=:section';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        $stmt->execute();

        $results = array();

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    public function retrieve_enrolled_desc($course,$section,$roundnum) {
        $sql = 'select * from enrolled where course=:course and section=:section and roundnum=:roundnum order by amount desc, userid asc';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        $stmt->bindParam(':roundnum', $roundnum, PDO::PARAM_STR);
        $stmt->execute();

        $results = array();

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    public function retrieve_enrolled_succ_desc($course,$section,$roundnum) {
        $sql = "select * from enrolled where course=:course and section=:section and roundnum=:roundnum and stat='successful' order by amount desc, userid asc";
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        $stmt->bindParam(':roundnum', $roundnum, PDO::PARAM_STR);
        $stmt->execute();

        $results = array();

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    //retrieve successful enrolls from specific course and section and $roundnum
    public function retrieve_allround_success($course,$section) {
        $sql = "select * from enrolled where course=:course and section=:section and stat='successful' order by amount desc, userid asc";
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        $stmt->execute();

        $results = array();

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //retrieve successful enrolls from specific course and section and $roundnum
    public function retrieve_success_enrolled($course,$section,$roundnum) {
        $sql = "select * from enrolled where course=:course and section=:section and roundnum=:roundnum and stat='successful'";
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        $stmt->bindParam(':roundnum', $roundnum, PDO::PARAM_STR);
        $stmt->execute();

        $results = array();

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    //retrieve successful enrolls of a student
    public function retrieve_user_success_enrolled($userid) {
        $sql = "select * from enrolled where userid=:userid and stat='successful'";
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->execute();

        $results = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    //retrieve successful enrolls of a student, with order
    public function retrieve_user_success_enrolled2() {
        $sql = "select * from enrolled where stat='successful' order by course, userid";
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->execute();

        $results = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    public function retrieve_round_enrolled1($roundnum) {
        $sql = "select * from enrolled where roundnum=:roundnum order by course, section, amount desc, userid";
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':roundnum', $roundnum, PDO::PARAM_STR);
        $stmt->execute();

        $results = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    //
    public function retrieve_round_succ_enrolled1($roundnum) {
        $sql = "select * from enrolled where roundnum=:roundnum and stat='successful'order by course,userid";
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':roundnum', $roundnum, PDO::PARAM_STR);
        $stmt->execute();

        $results = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    public function retrieve_unsuccess_enrolled($roundnum) {
        $sql = "select * from enrolled where  roundnum=:roundnum and stat='unsuccessful'";
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        // $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        // $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        $stmt->bindParam(':roundnum', $roundnum, PDO::PARAM_STR);
        $stmt->execute();

        $results = array();

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //this will retrieve the specific enrolled course
    public  function retrieve_enrolled($userid,$course,$section) {
        $sql = 'select * from enrolled where userid=:userid and course=:course and section=:section';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        $stmt->execute();

        

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            return new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        
    }
    //
    
    public  function retrieve_enrolled_course($userid,$course) {
        $sql = 'select * from enrolled where userid=:userid and course=:course';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->execute();

        

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            return new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        
    }

    public function retrieve_enrolled_succ_course($userid,$course) {
        $sql = 'select * from enrolled where userid=:userid and course=:course and stat= "successful"';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->execute();

        

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            return new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        
    }

    //this will retrieve the all the enrolled course
    public  function retrieve($userid) {
        $sql = 'select * from enrolled where userid=:userid';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->execute();

        $results = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    public  function retrieve_round($userid,$roundnum) {
        $sql = 'select * from enrolled where userid=:userid and roundnum=:roundnum';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->bindParam(':roundnum', $roundnum, PDO::PARAM_STR);
        $stmt->execute();

        $results = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }
    //
    //
    public  function retrieve_round_success($userid,$roundnum) {
        $sql = "select * from enrolled where userid=:userid and roundnum=:roundnum and stat='successful'";
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->bindParam(':roundnum', $roundnum, PDO::PARAM_STR);
        $stmt->execute();

        $results = [];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[] = new Enrolled($row['userid'], $row['course'], $row["section"],$row["amount"], $row["roundnum"],$row["stat"]);
        }
        return $results;
        
    }

    // When get enrolled to a course---- insert a row to enrolled table
    public function add_enrolled($enrolled) {
        $sql = 'INSERT INTO enrolled (userid, course, section,amount,roundnum,stat) VALUES (:userid, :course, :section,:amount, :roundnum, :stat)';
        
        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        $stmt->bindParam(':userid', $enrolled->userid, PDO::PARAM_STR);
        $stmt->bindParam(':course', $enrolled->course, PDO::PARAM_STR);
        $stmt->bindParam(':section',$enrolled->section, PDO::PARAM_STR);
        $stmt->bindParam(':amount',$enrolled->amount, PDO::PARAM_STR);
        $stmt->bindParam(':roundnum',$enrolled->roundnum, PDO::PARAM_STR);
        $stmt->bindParam(':stat',$enrolled->stat, PDO::PARAM_STR);
        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;
    }

   

    // When drop course after enrolled--- delete a row from enrolled table
    public function drop($enrolled) {
        
        $sql='DELETE FROM enrolled WHERE userid = :userid and course=:course and section=:section' ;

        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        
        $stmt->bindParam(':userid', $enrolled->userid, PDO::PARAM_STR);
        $stmt->bindParam(':course', $enrolled->course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $enrolled->section, PDO::PARAM_STR);
        
        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;

    }

    // delete all rows under the section from enrolled table
    public function drop_section($course,$section,$roundnum) {
        
        $sql='DELETE FROM enrolled WHERE course=:course and section=:section and roundnum=:roundnum' ;

        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        $stmt->bindParam(':roundnum', $roundnum, PDO::PARAM_STR);

        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;

    }
    public function update_status($enrolled) {
        
        $sql='UPDATE enrolled SET stat=:stat WHERE userid = :userid and course=:course and section=:section';
        
        
        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        
        $stmt->bindParam(':userid', $enrolled->userid, PDO::PARAM_STR);
        $stmt->bindParam(':stat', $enrolled->stat, PDO::PARAM_STR);
        $stmt->bindParam(':course', $enrolled->course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $enrolled->section, PDO::PARAM_STR);
        
        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;
    }
    ////when drop a enrolled course 2)refund the money by adding amount back to "edollar" in student table
    public function refund_when_drop($user,$amt) {
        
        $sql='UPDATE student SET edollar=edollar+:amount WHERE userid=:userid';

        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        
        $stmt->bindParam(':userid', $user, PDO::PARAM_STR);
        $stmt->bindParam(':amount', $amt, PDO::PARAM_STR);
        
        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;
    }

    public function refund_when_unsuccessful($user,$amt) {
        
        $sql='UPDATE student SET edollar=edollar+:amount WHERE userid=:userid';

        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        
        $stmt->bindParam(':userid', $user, PDO::PARAM_STR);
        $stmt->bindParam(':amount', $amt, PDO::PARAM_STR);
        
        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;
    }
    public function removeAll() {
        $sql = 'TRUNCATE TABLE enrolled';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
        $stmt = $conn->prepare($sql);
        
        $stmt->execute();
        $count = $stmt->rowCount();
    }

   
}
?>   