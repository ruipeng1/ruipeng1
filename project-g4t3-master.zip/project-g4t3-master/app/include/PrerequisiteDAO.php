<?php

class PrerequisiteDAO{
    #this will retrieve the all the specific course that needs prerequisites.
    public  function retrieve($course) {
        $sql = 'select * from prerequisite where course=:course';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->execute();

        $result = [];
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] =  new Prerequisite($row['course'], $row['prerequisite']);
        }   
        
        return $result;
    }
    
    #this will retrieve all the courses and prequisite in the system.
    public  function retrieveAll() {
        $sql = 'select * from prerequisite';
        
        $connMgr = new ConnectionManager();      
        $conn = $connMgr->getConnection();

        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        $result = array();


        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] = new Prerequisite($row['course'], $row['prerequisite']);
        }
        return $result;
    }

    #this will retrieve all the courses and prequisite in the system. with order
    public  function retrieveAll2() {
        $sql = 'select * from prerequisite order by course,prerequisite ';
        
        $connMgr = new ConnectionManager();      
        $conn = $connMgr->getConnection();

        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        $result = array();


        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] = new Prerequisite($row['course'], $row['prerequisite']);
        }
        return $result;
    }

    #add course with the required prerequisite
    public function add($Prerequisite) {

        $sql = 'INSERT IGNORE into prerequisite(course, prerequisite) values (:course, :prerequisite)';
        
        $connMgr = new ConnectionManager();      
        $conn = $connMgr->getConnection();
        $stmt = $conn->prepare($sql);
        
        $stmt->bindParam(':course', $Prerequisite->course, PDO::PARAM_STR);
        $stmt->bindParam(':prerequisite', $Prerequisite->prerequisite, PDO::PARAM_STR);

        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        $stmt = null;
        $pdo = null;

        return $isAddOK;
    }

    public function removeAll() {

        $connMgr = new ConnectionManager();
        $pdo= $connMgr->getConnection();

        $sql = 'TRUNCATE TABLE prerequisite';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();

        $count = $stmt->rowCount();

        $stmt = null;
        $pdo = null;
    }
}

?>