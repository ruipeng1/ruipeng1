<?php

class Course_completedDAO{
    #this will retrieve all completed courses by the user.
    public  function retrieve($userid) {
        $sql = 'select * from course_completed where userid=:userid';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->execute();

        $results=[];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $results[]=new Course_completed($row['userid'], $row['code']);
        }
        return $results;
    }
    
    //new*
    public  function retrieveSpecific($userid, $course) {
        $sql = 'select * from course_completed where userid=:userid and code=:code';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':userid', $userid, PDO::PARAM_STR);
        $stmt->bindParam(':code', $course, PDO::PARAM_STR);
        $stmt->execute();

        

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            return new Course_completed($row['userid'], $row['code']);
        }
        
    }
    #this will retrieve all the courses completed in the system.
    public  function retrieveAll() {
        $sql = 'select * from course_completed';
        
        $connMgr = new ConnectionManager();      
        $conn = $connMgr->getConnection();

        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        $result = array();


        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] =  new Course_completed($row['userid'], $row['code']);
        }
        return $result;
    }

    #this will retrieve all the courses completed in the system.
    public  function retrieveAll2() {
        $sql = 'select * from course_completed order by code, userid';
        
        $connMgr = new ConnectionManager();      
        $conn = $connMgr->getConnection();

        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        $result = array();


        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] =  new Course_completed($row['userid'], $row['code']);
        }
        return $result;
    }

    #this will add new completed course
    public function add($course) {
        $sql = "INSERT IGNORE INTO course_completed (userid,code) VALUES (:userid, :code)";

        $connMgr = new ConnectionManager();      
        $conn = $connMgr->getConnection();
        $stmt = $conn->prepare($sql);
        

        $stmt->bindParam(':userid', $course->userid, PDO::PARAM_STR);
        $stmt->bindParam(':code', $course->code, PDO::PARAM_STR);
        

        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;
    }

    public function removeAll() {
        $sql = 'TRUNCATE TABLE course_completed';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
        $stmt = $conn->prepare($sql);
        
        //$stmt->execute();
        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        
        return $isAddOK;
        $count = $stmt->rowCount();
        
    }
}

?>