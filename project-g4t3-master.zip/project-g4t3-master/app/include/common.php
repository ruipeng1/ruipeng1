<?php

// this will autoload the class that we need in our code
spl_autoload_register(function($class) {
 
    // we are assuming that it is in the same directory as common.php
    // otherwise we have to do
    // $path = 'path/to/' . $class . ".php"    
    require_once "$class.php"; 
  
});


// session related stuff

session_start();


function printErrors() {
    if(isset($_SESSION['errors'])){
        echo "<ul id='errors' style='color:red;'>";
        
        foreach ($_SESSION['errors'] as $value) {
            echo "<li>" . $value . "</li>";
        }
        
        echo "</ul>";   
        unset($_SESSION['errors']);
    }    
}



function isMissingOrEmpty($name) {
    if (!isset($_REQUEST[$name])) {
        return "missing $name";
    }

    // client did send the value over
    $value = $_REQUEST[$name];
    if (empty($value)) {
        return "blank $name";
    }
}

# check if an int input is an int and non-negative
function isNonNegativeInt($var) {
    if (is_numeric($var) && $var >= 0 && $var == round($var))
        return TRUE;
}

# check if a float input is is numeric and non-negative
function isNonNegativeFloat($var) {
    if (is_numeric($var) && $var >= 0)
        return TRUE;
}
# *new* check if a float input is numeric and non-negative, decimal places from 0~2
function isNonNegative($var) {
    if (is_numeric($var) && $var >= 0 &&($var == round($var)||$var == round($var,1) || $var == round($var,2)))
        return TRUE;
}

# this is better than empty when use with array, empty($var) returns FALSE even when
# $var has only empty cells
function isEmpty($var) {
    if (isset($var) && is_array($var))
        foreach ($var as $key => $value) {
            if (empty($value)) {
               unset($var[$key]);
            }
        }

    if (empty($var))
        return TRUE;
}

function validateUserIDlen($userid){
    if (strlen($userid)>128){
        return TRUE;
    }
    else{
        return FALSE;
    }
}

function validateNamelen($name){
    if (strlen($name)>100){
        return TRUE;
    }
    else{
        return FALSE;
    }
}

function validatePasswordlen($pw){
    if (strlen($pw)>128){
        return TRUE;
    }
    else{
        return FALSE;
    }
}

function validateDecimals($edollar){
    if(preg_match('/\.\d{3,}/', $edollar)){
        return TRUE;
    }
    else{
        return FALSE;
    }
}

#check if end < start 
function CheckEndLargerthanStart($start,$end){
    $start = str_replace(':', '', $start);
    $end = str_replace(':', '', $end);
    if (strlen($start) <= 3) {
        $start = '0' . $start;
    }
    if (strlen($end) <= 3) {
        $end = '0' . $end;
    }
    $valid = FALSE;
    if ($end > $start){
        $valid = TRUE;
    }
    return $valid;
}


//to check if date is in the correct format
function validateDate($date, $format = 'Ymd'){
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

//to check if the time format is correct
function validateTime($time){
    if(strlen($time)==4){
        $time = "0".$time;
    }
    if(preg_match("/^(?:2[0-3]|[01][0-9]):[0-5][0-9]$/", $time)){
        return true;
    }
    return false;
}

//check if selected course exist in the DB course table 
function checkCourseExist($course){
    $courseDAO = new CourseDAO();
    
    $courseArr = [];
    $all_courses = $courseDAO->retrieveAll();
    for($i = 0; $i <count($all_courses); $i++){
        $courseArr[] = $all_courses[$i]->getCourse();
    }

    return in_array($course, $courseArr);
}

//check if selected course exist in the DB course table 
function checkSessionExist($course, $section){
    $sql = 'select section from section where course=:course';
        
    $connMgr = new ConnectionManager();
    $conn = $connMgr->getConnection();
    
    $stmt = $conn->prepare($sql);
    $stmt->setFetchMode(PDO::FETCH_ASSOC);
    $stmt->bindParam(':course', $course, PDO::PARAM_STR);
    $stmt->execute();

    $result = array();

    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $result[] = $row['section'];
    }
    
    return in_array($section, $result);
}



function getCoursesBySch($curr_sch){
    $courseDAO = new CourseDAO();
    $courseArr = [];
    
    $all_courses = $courseDAO->retrieveAll();
    for($i = 0; $i <count($all_courses); $i++){
        $school = $all_courses[$i]->getSchool();
        if($school == $curr_sch){
            $courseArr[] = $all_courses[$i]->getCourse();
        }	
    }
    return $courseArr;
}



function checkTimeClash($currStart, $currEnd, $existStart, $existEnd){
//    echo "start ".$currStart. "   -------  " . $existEnd. "    ";
//    echo "end  ".$currEnd . "   -------  " . $existStart." ";    

//    echo $currStart;
//    echo $currEnd;
    //echo $currStart == $existEnd;
    

    //--
   //return ($currStart >= $existStart && $currEnd <= $existEnd );
   return ($currStart >= $existStart && $currEnd <= $existEnd  );
    //return($currStart>$existEnd);
    //return ($currStart > $currEnd || $existStart <  $currEnd);
}

//*new*
function checkTimeClash2($currStart, $currEnd, $existStart, $existEnd){
    if (($currEnd<=$existStart) || ($currStart>=$existEnd)){
        return FALSE;//no clash
    }
    return TRUE;//clash
        
}

function checkCourseCompleted($user, $course){
    $course_completedDAO = new Course_completedDAO();
    $courseCompletedArr = []; 
    $codeArr = [];

    $courseCompletedArr = $course_completedDAO -> retrieve($user);

    for($i = 0; $i<count($courseCompletedArr); $i++){
        $codeArr[] = $courseCompletedArr[$i] ->getCode();
    }

    
    return in_array($course, $codeArr);
}



function checkPreReqExist($course){
    $prerequisiteDAO = new PrerequisiteDAO();
    
    $allPreReqCourseArr = [];
    $allPreReqArr = [];

    $allPreReqCourseArr = $prerequisiteDAO -> retrieve($course) ;
    
    if($allPreReqCourseArr !== null){
        for($i=0; $i<count($allPreReqCourseArr); $i++){						
            $allPreReqArr[] = $allPreReqCourseArr[$i] -> getPrequisite();
        }
    
    }

    //var_dump($allPreReqArr);
    return $allPreReqArr;
}

//-------------------------cart 
function checkDuplicateCourse($course, $courseArr){
    $count = 0;
    foreach($courseArr as $courseCode){
        $strArr = explode(',', $courseCode);
        $code = $strArr[0];
        $section = $strArr[1];

        if($course == $code){
            $count ++;
        }
    }
    if($count > 1){
        return true;
    }
    return false;
}