<?php
require_once 'common.php';

function doBootstrap() {
	$errors = array();
	$error_msg = [];
	# need tmp_name -a temporary name create for the file and stored inside apache temporary folder- for proper read address
	$zip_file = $_FILES["bootstrap-file"]["tmp_name"];

	# Get temp dir on system for uploading
	$temp_dir = sys_get_temp_dir();

	# keep track of number of lines successfully processed for each file
	$bid_processed=1;
	$success_bid_processed=0;

	$course_processed=1;
	$success_course_processed=0;

	$course_completed_processed=1;
	$course_completed_processed_sucess = 0;

	$prerequisite_processed=1;
	$success_prerequisite_processed=0;

	$section_processed=1;
	$success_section_processed=0;

	$student_processed=1;
	$success_student_processed=0;

	$error_bid = [];
	$error_section = [];
	$error_cc = [];
	$error_course = [];
	$error_prereq = [];
	$error_student = [];

	
	
	
	
	$file_exist = false;
	# check file size
	if ($_FILES["bootstrap-file"]["size"] <= 0)
		$errors[] = "input files not found";

	else {
		
		$zip = new ZipArchive;
		$res = $zip->open($zip_file);

		if ($res === TRUE) {
			$zip->extractTo($temp_dir);
			$zip->close();
		
			$bid_path = "$temp_dir/bid.csv";
			$course_path = "$temp_dir/course.csv";
			$course_completed_path = "$temp_dir/course_completed.csv";
			$prerequisite_path = "$temp_dir/prerequisite.csv";
			$section_path = "$temp_dir/section.csv";
			$student_path = "$temp_dir/student.csv";
			
			
			$bid = @fopen($bid_path, "r");
			$course = @fopen($course_path, "r");
			$course_completed = @fopen($course_completed_path, "r");
			$prerequisite = @fopen($prerequisite_path, "r");
			$section = @fopen($section_path, "r");
			$student = @fopen($student_path, "r");
			

			if (empty($bid) || empty($course) || empty($course_completed) || empty($prerequisite) || empty($section) || empty($student)){
				$errors[] = "input files not found";
				if (!empty($bid)){
					fclose($bid);
					@unlink($bid_path);
				} 
				
				if (!empty($course)) {
					fclose($course);
					@unlink($course_path);
				}
				
				if (!empty($course_completed)) {
					fclose($course_completed);
					@unlink($course_completed_path);
				}

				if (!empty($prerequisite)) {
					fclose($prerequisite);
					@unlink($prerequisite_path);
				} 

				if (!empty($section)) {
					fclose($section);
					@unlink($section_path);
				} 

				if (!empty($student)) {
					fclose($student);
					@unlink($student_path);
				}
				
				
			}
			else {
				$file_exist = true;
				$connMgr = new ConnectionManager();
				$conn = $connMgr->getConnection();

				# start processing
								
				// --------------------------------------------student---------------------------------------------------------- 
				$studentDAO = new StudentDAO();
				$studentDAO -> removeAll();
				// process each line, check for errors, then insert if no errors
				$data = fgetcsv($student);

				while ( ($data = fgetcsv($student)) !== false){
					
					$error_msg = [];
					$userID = trim($data[0]);
					$password = trim($data[1]);
					$name = trim($data[2]);
					$school = trim($data[3]);
					$edollar = trim($data[4]);

					if (empty($userID) || empty($password) || empty($name) || empty($school) || empty($edollar)){
						if (empty($userID)){
							$error_msg[] = "blank userid";
						}
						if (empty($password)){
							$error_msg[] = "blank password";
						}
						if (empty($name)){
							$error_msg[] = "blank name";
						}
						if (empty($school)){
							$error_msg[] = "blank school";
						}
						if (($edollar == null)){
							$error_msg[] = "blank edollar";
						}
						}
						
						else{
							#check for duplicate
						if($studentDAO->retrieve($userID)){
							$error_msg[] = "duplicate userid";
							}
							#check userid length
						if(validateUserIDlen($userID)){
							$error_msg[] = "invalid userid";
							}  
							#check edollar decimal and less than zero
						if (validateDecimals($edollar) || $edollar<0 || !is_numeric($edollar)){
							$error_msg[] = "invalid e-dollar";
						}	
						#check password length
							if(validatePasswordlen($password)){
							$error_msg[] = "invalid password";
							}
							#check name length
							if(validateNamelen($name)){
							$error_msg[] = "invalid name";
							}
						}

						$student_processed++;
						if(empty($error_msg)){
							$studentObj = new Student($userID,$password,$name,$school,$edollar);
							$studentDAO ->add($studentObj);
							$success_student_processed++;
							
						}
						else{
							$error_student[] = [
							"file"=>"student.csv",
							"line"=>$student_processed,
							"message"=>$error_msg
							];
							
						}
						}
				// clean up
				if($error_student){
					$errors[] = $error_student;
				}
				fclose($student);
				@unlink($student_path);
				
				// ------------------------------------------   COURSE -------------------------------------------------
				$courseDAO = new CourseDAO();
				$courseDAO -> removeAll();
				// process each line, check for errors, then insert if no errors
				$data = fgetcsv($course);

				while ( ($data = fgetcsv($course)) !== false){
					$error_msg = [];

					$courseID = trim($data[0]);
					$course_school = trim($data[1]);
					$course_title = trim($data[2]);
					$course_des = trim($data[3]);
					$course_exam_date = trim($data[4]);
					$exam_start_time = trim($data[5]);
					$exam_end_time = trim($data[6]);

					$courseID_status = false;

					
					
					if(empty($courseID)||empty($course_school)||empty($course_title)||empty($course_des)||empty($course_exam_date)
						|| empty($exam_start_time) || empty($exam_end_time)){

						
						if (empty($courseID)){
							$error_msg[] = "blank course";
						}

						if (empty($course_school)){
							$error_msg[] = "blank school";
						}

						if (empty($course_title)){
							$error_msg[] = "blank title";
						}
						
						if (empty($course_des)){
							$error_msg[] = "blank description";
						}

						if (empty($course_exam_date)){
							$error_msg[] = "blank exam date";
						}

						if (empty($exam_start_time)){
							$error_msg[] = "blank exam start";
						}

						if (empty($exam_end_time)){
							$error_msg[] = "blank exam end";
						}
					}else{

						
						
						if(strlen($course_title) > 100){
							$error_msg[] = "invalid title";
						}

						if(strlen($course_des) > 1000){
							$error_msg[] = "invalid description";
						}

						if(validateDate($course_exam_date) == false){
							$error_msg[] = "invalid exam date";
						}

						if(!validateTime($exam_start_time)){
							$error_msg[] = "invalid exam start";
						}

						if(!validateTime($exam_end_time)){
							$error_msg[] = "invalid exam end";
						}else if(!CheckEndLargerthanStart($exam_start_time,$exam_end_time)){
							$error_msg[] = "invalid exam end";
						}

						
					}
				
					$course_processed++;
					if(empty($error_msg)){
						$courseObj = new Course ($courseID, $course_school, $course_title, $course_des, $course_exam_date, $exam_start_time, $exam_end_time);
						$courseDAO -> add($courseObj);
						$success_course_processed++;
						
					}else{
						$error_course[] = [
						  "file"=>"course.csv",
						  "line"=>$course_processed,
						  "message"=>$error_msg
						];
						
					}
				}
				// clean up
				if ($error_course){
					$errors[] = $error_course;
				}
				
				fclose($course);
				@unlink($course_path);
				
			
				
				// ------------------------------------prerequisite -------------------------------------------------------------------------
				$prerequisiteDAO = new PrerequisiteDAO();
				$prerequisiteDAO -> removeAll();
				// process each line, check for errors, then insert if no errors
				$data = fgetcsv($prerequisite);

				while ( ($data = fgetcsv($prerequisite)) !== false){
					$error_msg = [];
					$course_code = trim($data[0]);
					$prereq = trim($data[1]);
					
					if(empty($course_code) || empty($prereq)){
						if (empty($course_code)){
							$error_msg[] = "blank course";
						}
						
						if (empty($prereq)){
							$error_msg[] = "blank prerequisite";
						}
						
					}else{
						if (checkCourseExist($course_code) == false){
							$error_msg[] = "invalid course";
						}
						
						if (checkCourseExist($prereq) == false){
							$error_msg[] = "invalid prerequisite";
						}
					}
					

					
					$prerequisite_processed++;
					if(empty($error_msg)){
						$prerequisiteObj = new Prerequisite ($course_code, $prereq);
						$prerequisiteDAO -> add($prerequisiteObj);
						$success_prerequisite_processed++;
						
					}else{
						$error_prereq[] = [
						  "file"=>"prerequisite.csv",
						  "line"=>$prerequisite_processed,
						  "message"=>$error_msg
						  ];
						 
					}			
				}
				// clean up
				if ($error_prereq){
					$errors[] = $error_prereq;
				}
				fclose($prerequisite);
				@unlink($prerequisite_path);
				
					// -------------------------------------------course_completed-------------------------------------------------------
					$course_completedDAO = new Course_completedDAO();
					$course_completedDAO -> removeAll();
					$cc_studentDAO = new StudentDAO();
					$cc_prereqDAO = new PrerequisiteDAO();
					// process each line, check for errors, then insert if no errors
					$data = fgetcsv($course_completed);
	
					
					while ( ($data = fgetcsv($course_completed)) !== false){
						$error_msg = [];
						//$user_coursesArr = [];
						$cc_userID = trim($data[0]);
						$cc_course = trim($data[1]);
						
						if(empty($cc_userID)||empty($cc_course)){
							if (empty($cc_userID)){
								$error_msg[] = "blank userid";
							}
							
							if (empty($cc_course)){
								$error_msg[] = "blank code";
							}

						}else{
							if($cc_studentDAO->retrieve($cc_userID)==null){
								$error_msg[] = "invalid userid";
							}

							if (checkCourseExist($cc_course) == false){
								$error_msg[] = "invalid course";
							}
						}
						


						
	
						// --------------------proceed with validation--------------------
						if(!empty($cc_userID)&&!empty($cc_course)){

							if(!empty(checkPreReqExist($cc_course))){
								$cc_prereqCourses = checkPreReqExist($cc_course);
								for($i = 0; $i<count($cc_prereqCourses);$i++){
									if (checkCourseCompleted($cc_userID, $cc_prereqCourses[$i])==false){
										$error_msg[] = "invalid course completed";
									}
								}
							}
						}
						
	
						$course_completed_processed++;
						if(empty($error_msg)){
							$course_completedObj = new Course_completed($cc_userID, $cc_course);
							$course_completedDAO -> add($course_completedObj);
							$course_completed_processed_sucess++;
							
						}else{
							$error_cc[] = [
							  "file"=>"course_completed.csv",
							  "line"=>$course_completed_processed,
							  "message"=>$error_msg
							  ];
							  
						}			
					}
				//}
					// clean up
					if ($error_cc){
						$errors[] = $error_cc;
					}
					fclose($course_completed);
					@unlink($course_completed_path);
				// ------------------------------------------------section ----------------------------------------------------------
				$sectionDAO = new SectionDAO();
				$sectionDAO -> removeAll();
				// process each line, check for errors, then insert if no errors
				$data = fgetcsv($section);

				while ( ($data = fgetcsv($section)) !== false){
					$error_msg = [];

					$course = trim($data[0]);
					$section1 = trim($data[1]);
					$section_num = substr($section1,1);
			
					$day = trim($data[2]);
					$start = trim($data[3]);
					$end = trim($data[4]);
					$instructor = trim($data[5]);
					$venue = trim($data[6]);
					$size = trim($data[7]);

					$days = ["1","2","3","4","5","6","7"];
					$endTime = false;
					$startTime = false;
					
					if(empty($course)||empty($section1)||$day==null||empty($start)||empty($end) || empty($instructor)|| empty($venue)
						|| $size==""){

						
						if (empty($course)){
							$error_msg[] = "blank course";
						}
						
						if (empty($section1)){
							$error_msg[] = "blank section";
						}

						if ($day==null){
							$error_msg[] = "blank day";
						}

						if (empty($start)){
							$error_msg[] = "blank start";
						}

						if (empty($end)){
							$error_msg[] = "blank end";
						}


						if (empty($instructor)){
							$error_msg[] = "blank instructor";
						}


						if (empty($venue)){
							$error_msg[] = "blank venue";
						}


						if ($size==""){
							$error_msg[] = "blank size";
						}
					}else{

				
						if(checkCourseExist($course) == false){
							$error_msg[] = "invalid course";
						}					
						
						if (!isNonNegativeInt($section_num) || $section_num > 99 || strtoupper($section1[0]) !== "S" || $section_num == 0){
							$error_msg[] = "invalid section";
						}
						
						if(in_array($day, $days)==false){
							$error_msg[] = "invalid day";
						}			
						
						if(!validateTime($start)){
							$error_msg[] = "invalid start";
						}else{
							$startTime = true;
						}

						if($startTime){						
							if(!validateTime($end)){
								$error_msg[] = "invalid end";
							}else{
								$endTime = true;
							}	
						}
						

						if($endTime && $startTime){
							if(!CheckEndLargerthanStart($start,$end)){
								$error_msg[] = "invalid end";
							}
						}
											
						
						if(is_numeric($instructor) || strlen($instructor) > 100){
							$error_msg[] = "invalid instructor";
						}					
						
						if (strlen($venue)>100){
							$error_msg[] = "invalid venue";
						}

						
						if (validateDecimals($size) || !isNonNegativeInt($size) || $size ==0){
							$error_msg[] = "invalid size";
						}
					}
					$section_processed++;
					//add section when no error
					if(empty($error_msg)){
						$sectionObj = new Section ($course, $section1, $day, $start, $end, $instructor, $venue,	$size);
						$sectionDAO -> add($sectionObj);
						
						$success_section_processed++;
						
					  }else{
						$error_section[] = [
						  "file"=>"section.csv",
						  "line"=>$section_processed,
						  "message"=>$error_msg
						  ];
						 
					}


				}
				// clean up
				if($error_section){
					$errors[] = $error_section;
				}
				
				fclose($section);
				@unlink($section_path);
	
			// -------------------------------------------round-------------------------------------------------------

			$roundDAO = new RoundnumDAO();
			$roundDAO -> removeAll();
			$roundnum = 1;
				
			
			$roundObj = new Roundnum($roundnum);
			$roundDAO -> add($roundObj);

				
		// -------------------------------------------BID-------------------------------------------------------
		$success_bid_processed = 0;
		$allStudentArr = []; //to store every bid user data with day and time (associative Arr)
		$concludeCourseBid = [];//to store and count the edollar and section limit for each student
		
		
		

        $bidDAO = new BidDAO();
        $bidDAO -> removeAll();
        
        // process each line, check for errors, then insert if no errors
        $data = fgetcsv($bid);
          
		$error_bid= [];
		
        while ( ($data = fgetcsv($bid)) !== false){

          
			$user_BidArr=[];
			$error_msg=[];  
			$bid_userID = trim($data[0]);
			$bid_amt = trim($data[1]);
			$bid_course = trim($data[2]);
			$bid_section = trim($data[3]);
			
			//------------------
			//set all requirements to be false
			$bidUserIdValid = false;
			$amtValid = false;
			$courseValid = false;
			$sectionValid = false;
			//------------------
			$notEmptyUser = false;
			$notEmptyBid = false;
			$notEmptyCourse =false;
			$notEmptySection =false;

			if (empty($bid_userID)){
				$error_msg[] = "blank userid";
			}else{
				$notEmptyUser = true;
			}

			if (empty($bid_amt)){
				$error_msg[] = "blank amount";
			}else{
				$notEmptyBid = true;
			}

			if (empty($bid_course)){
				$error_msg[] = "blank code";
			}else{
				$notEmptyCourse = true;
			}

			if (empty($bid_section)){
				$error_msg[] = "blank section";
				
			}else{
				$notEmptySection = true;
			}
			
		if($notEmptyUser&&$notEmptyBid&&$notEmptyCourse&&$notEmptySection ){
			if($studentDAO->retrieve($bid_userID)==null){
				$error_msg[] = "invalid userid";
			}else{
				$bidUserIdValid = true;
			}


				if(!is_numeric($bid_amt)|| $bid_amt<10 || validateDecimals($bid_amt)){
					$error_msg[] = "invalid amount";
				}else{
					$amtValid = true;
				}
			
		
			if (checkCourseExist($bid_course) == false){
				$error_msg[] = "invalid course";
			}else{
				$courseValid = true;
			}
	
			if ($courseValid ){
				//if courseid exists, check if section is within the course 
				 if (checkSessionExist($bid_course, $bid_section) == false){
					$error_msg[] = "invalid section";	
				}else{
					$sectionValid = true;
				}
			}

		}
			//--------------------------Process logic validation---------------------
			
			$currRound = $roundDAO -> retrieveAll()->getRound();

			$courseCheckOk = false;
			$noClashOk = false;
			$courseNotCompleteOk = false;
			$prereqOk = false;
			$bid_status = false;

			
			
			if($bidUserIdValid && $amtValid && $courseValid && $sectionValid){
				//----students are allowed to bid for modules from their own school--
				if($currRound == "1"){					
					$student_sch = $studentDAO->retrieve($bid_userID)->getSchool();
					
					$courses_by_school = getCoursesBySch($student_sch);
					if (in_array($bid_course, $courses_by_school) == false){
						$error_msg[] = "not own school course";
					}else{
						$courseCheckOk = true;
					}
				}

				//--The class timeslot for the section clashes with that of a previously bidded section--
				
				//to store value as associative array
				$currStudentInfo = [];

				$curr_section_time_start = $sectionDAO ->retrieve($bid_course, $bid_section)->getStart();
				$curr_section_time_end = $sectionDAO ->retrieve($bid_course, $bid_section)->getEnd();

				$curr_exam_time_start = $courseDAO ->retrieve($bid_course)->getExam_start();
				$curr_exam_time_end = $courseDAO ->retrieve($bid_course)->getExam_end();


				$curr_exam_date = $courseDAO ->retrieve($bid_course)->getExam_date();
				$curr_section_day = $sectionDAO ->retrieve($bid_course, $bid_section)->getDay();

				
				
			
				if (array_key_exists($bid_userID, $allStudentArr)){
					
					foreach($allStudentArr as $key => $infoDataArr){

						$classNotClash= false;
						$examNotClash= false;
						if($key == $bid_userID){
						
						$error_msg=[];
						$existStart = $infoDataArr["start"];
						$existEnd = $infoDataArr["end"];
						$existExamS = $infoDataArr["examstart"];
						$existExamE = $infoDataArr["examend"];
						$curr_section = $infoDataArr["section"];

						$existCourse = $infoDataArr["course"];
						
						
						if ($bid_course != $existCourse){
							if(checkTimeClash2($curr_section_time_start,$curr_section_time_end, $existStart,$existEnd) && $curr_section_day == $infoDataArr["day"] ){
								$error_msg[] = "class timetable clash";
							}else{
								$classNotClash= true;
							}
						}
						

						if ($bid_course != $existCourse){

							
							if (checkTimeClash2($curr_exam_time_start,$curr_exam_time_end, $existExamS,$existExamE) && $curr_exam_date == $infoDataArr["examdate"]){
								$error_msg[] = "exam timetable clash";					
							}else{
								$examNotClash = true;
							}
						}
							
						
						//add course complete validation here.
						if($examNotClash && $classNotClash){
							$currStudentInfo["start"] = $curr_section_time_start;
							$currStudentInfo["end"] = $curr_section_time_end;
							$currStudentInfo["examstart"] = $curr_exam_time_start;
							$currStudentInfo["examend"] = $curr_exam_time_end;

							$currStudentInfo["examdate"] = $curr_exam_date;
							$currStudentInfo["day"] = $curr_section_day;

							$currStudentInfo["section"] = $bid_section;

							$currStudentInfo["course"] = $bid_course;
							
							array_push($allStudentArr[$bid_userID], $currStudentInfo);
							$noClashOk = true;	

						}
					 }
					}	
						
				}else{
					
					$currStudentInfo["start"] = $curr_section_time_start;
					$currStudentInfo["end"] = $curr_section_time_end;
					$currStudentInfo["examstart"] = $curr_exam_time_start;
					$currStudentInfo["examend"] = $curr_exam_time_end;

					$currStudentInfo["examdate"] = $curr_exam_date;
					$currStudentInfo["day"] = $curr_section_day;

					$currStudentInfo["section"] = $bid_section;

					$currStudentInfo["course"] = $bid_course;
					
					
					$allStudentArr[$bid_userID] = $currStudentInfo;
					
					$noClashOk = true;
				}
			
				
					if (checkCourseCompleted($bid_userID, $bid_course)){
						$error_msg[] = "course completed";
					}
				
				
				// to check if prereq is completed
				$countPreReq = 0; // to prevent printint multiple times
				if(!empty(checkPreReqExist($bid_course))){
					$prereqCourses = checkPreReqExist($bid_course);

					for($i = 0; $i<count($prereqCourses);$i++){
						if (checkCourseCompleted($bid_userID, $prereqCourses[$i])==false){
							if ($countPreReq < 1){
								$error_msg[] = "incomplete prerequisites";
								$countPreReq++;
							}
							
						}
					}
				}
				

				$bidEntitled = $studentDAO->retrieve($bid_userID)->getEdollar();
				
				$first_amt = 0;
			
				$same_course_prev_bid = $bidDAO->retrieve_bid_course($bid_userID,$bid_course);
				$prev_bidAmt = 0;

				if (!empty($same_course_prev_bid)){
					$prev_bidAmt = $same_course_prev_bid->getAmount();
				}

				
				
						
				$success_bid_Arr = [];
				$success_bid_Arr = $bidDAO->retrieve($bid_userID);
						$totDollar = 0;
				if(!empty($success_bid_Arr)){
					
					for($i=0; $i<count($success_bid_Arr); $i++){
						$currDollar = $success_bid_Arr[$i]->getAmount();																
						$totDollar = $totDollar+$currDollar;	
					}

					
					// +1 --> to see if it's possible to add another data
					if(count($success_bid_Arr) + 1 > 5){ //change the value to 5
						$error_msg[] = "section limit reached";
					}
				}

				$existDollar = floatval($totDollar) + floatval($bid_amt);
				
				if(floatval($bid_amt) >floatval($bidEntitled) + floatval($prev_bidAmt)){
					$error_msg[] = "not enough e-dollar";
				}
					
				
								

			}//end if
			
			
			$bid_processed++;
			
			
			if(empty($error_msg)){

				
					$drop_status = $bidDAO->drop($same_course_prev_bid);
					if($drop_status){
						$bidDAO->refund_when_drop_bid($bid_userID, $prev_bidAmt);
					}
				
				

				//-to add into DB and deduct edollar ---------------------------------------------
				$bidObj = new Bid ($bid_userID,$bid_amt,$bid_course,$bid_section);
				$add_status = $bidDAO -> add($bidObj);
				if($add_status){
					$bidDAO -> deduct_when_add($bidObj); 
				}
				
				$success_bid_processed++;
				
			}else{
				$error_bid[] = [
				"file"=>"bid.csv",
				"line"=>$bid_processed,
				"message"=>$error_msg
				];
			}
              
		}
		
		
		// clean up
		if($error_bid){
			$errors[] = $error_bid;
		}
		
		
        
        fclose($bid);
		@unlink($bid_path);
		
		// -------------------------------bid in cart---------------------------

			}
		}
	}
	// Clear enrolled table
	$enrollDAO = new EnrolledDAO;
	$enrollDAO->removeAll();

	//clear bid in cart table
	$Bid_in_cartDAO = new Bid_in_cartDAO();
	$Bid_in_cartDAO -> removeAll();

	//clear minbid table and insert initial minbid for each section as as 10 
	$minBidDAO= new minBidDAO();
	$minBidDAO->removeAll();
	$sectionDAO= new SectionDAO();
	$sections=$sectionDAO->retrieveAll();
	$arr=[];

	foreach($sections as $section){
		$arr[]=[$section->getCourse(),$section->getSection()];	
	}

	foreach($arr as $item){
		$a=new minBid($item[0],$item[1],10);
		$minBidDAO->add($a);
	}

	# Sample code for returning JSON format errors. remember this is only for the JSON API. Humans should not get JSON errors.
	
	$noError =[];
	if (!isEmpty($errors))
	{	
		$new_errors = [];
		

		if($file_exist){
		
		foreach ($errors as $error => $values){
			foreach ($values as $keys => $values1){

				
					if ($values1["file"] == "bid.csv"){
						 $new_errors[] = $values1;
					}
				
			}
		}
		foreach ($errors as $error => $values){
			foreach ($values as $keys => $values1){

				
					if ($values1["file"] == "course.csv"){
						 $new_errors[] = $values1;
					}
				
			}
		}
		foreach ($errors as $error => $values){
			foreach ($values as $keys => $values1){

				
					if ($values1["file"] == "course_completed.csv"){
						 $new_errors[] = $values1;
					}
				
			}
		}
		foreach ($errors as $error => $values){
			foreach ($values as $keys => $values1){

				
					if ($values1["file"] == "prerequisite.csv"){
						 $new_errors[] = $values1;
					}
				
			}
		}
		foreach ($errors as $error => $values){
			foreach ($values as $keys => $values1){

				
					if ($values1["file"] == "section.csv"){
						 $new_errors[] = $values1;
					}
				
			}
		}
		foreach ($errors as $error => $values){
			foreach ($values as $keys => $values1){

				
					if ($values1["file"] == "student.csv"){
						 $new_errors[] = $values1;
					}
				
			}
		}
	}
		$result = [ 
			"status" => "error",
			"num-record-loaded" => [
			["bid.csv" => $success_bid_processed],
			["course.csv" => $success_course_processed],
			["course_completed.csv" => $course_completed_processed_sucess],
			["prerequisite.csv" => $success_prerequisite_processed],
			["section.csv" => $success_section_processed],
			["student.csv" => $success_student_processed]
			],
			"error" =>$new_errors
			
		  ];
		  

	}

	else
	{	
		$result = [ 
			"status" => "success",
			"num-record-loaded" => [
				["bid.csv" => $bid_processed-1],
				["course.csv" => $course_processed-1],
				["course_completed.csv" => $course_completed_processed-1],
				["prerequisite.csv" => $prerequisite_processed-1],
				["section.csv" => $section_processed-1],
				["student.csv" => $student_processed-1]
						

			]
		];
	}
	return $result;

	
}
?>