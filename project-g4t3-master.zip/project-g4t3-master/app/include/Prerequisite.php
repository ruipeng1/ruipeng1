
<?php
class Prerequisite{
    public $course;
    public $prerequisite;

    function __construct($course, $prerequisite){

        $this->course = $course;
        $this->prerequisite = $prerequisite;
     
    }

    function getCourse(){
        return  $this->course ;
    }

    function getPrequisite(){
        return  $this->prerequisite ;
    }

}



?>