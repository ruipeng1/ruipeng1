<?php
class minBidDAO{
    #this will retrieve all the minbids in the system.
    public  function retrieveAll() {
        $sql = 'select * from minBid';
        
        $connMgr = new ConnectionManager();      
        $conn = $connMgr->getConnection();

        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        $result =[];


        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result[] = new minBid($row['course'], $row["section"], $row["edollar"]);
        }
        return $result;
    }
    
    #retrieve specific minbid
    public  function retrieve_bid($course,$section) {
        $sql = 'select * from minBid where course=:course and section=:section';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
            
        $stmt = $conn->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $section, PDO::PARAM_STR);
        
        $stmt->execute();

        $result =[];

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $result = new minBid($row['course'], $row["section"], $row["edollar"]);
        }
        return $result;
    }

    //add a line to minBid
    public function add($minBid) {
        $sql = 'INSERT INTO minBid (course, section, edollar) VALUES (:course, :section, :edollar) ';
        
        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        
        $stmt->bindParam(':course', $minBid->course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $minBid->section, PDO::PARAM_STR);
        $stmt->bindParam(':edollar', $minBid->edollar, PDO::PARAM_STR);

        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;
    }
    
    //update edollar in a line in minbid table
    public function update($bid) {
        
        $sql='UPDATE minBid SET edollar=:edollar WHERE course=:course and section=:section ';
        
        
        $connMgr = new ConnectionManager();       
        $conn = $connMgr->getConnection();
         
        $stmt = $conn->prepare($sql); 

        
        $stmt->bindParam(':edollar', $bid->edollar, PDO::PARAM_STR);
        $stmt->bindParam(':course', $bid->course, PDO::PARAM_STR);
        $stmt->bindParam(':section', $bid->section, PDO::PARAM_STR);
        
        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        return $isAddOK;
    }

    public function removeAll() {
        $sql = 'TRUNCATE TABLE minBid';
        
        $connMgr = new ConnectionManager();
        $conn = $connMgr->getConnection();
        
        $stmt = $conn->prepare($sql);
        
        $stmt->execute();
        $count = $stmt->rowCount();
    }
}
?>