
<?php

Class CourseDAO{
    //Function 1: to extract information for all courses 
    public function retrieveAll() {
        // STEP 1         
        // Connect to database          
        // See 'ConnectionManager.php'  
        $connMgr = new ConnectionManager();      
        $pdo = $connMgr->getConnection();

        // STEP 2: Prepare SQL statement 
        $sql = 'select * from course';
        $stmt = $pdo->prepare($sql);

        // STEP 3: Run SQL   
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        //STEP 4: Retrieve query results
        $results = [];
        while($row = $stmt->fetch()) {
            $results[] = new Course($row['course'], $row['school'], $row['title'],$row["description"],$row['exam_date'],$row['exam_start'],$row['exam_end']);
        }

        // STEP 5: Close DB Connection & SQL Statement         
        $stmt = null;         
        $pdo = null; 

        return $results;
    }   

    public function retrieveAll2() {
        // STEP 1         
        // Connect to database          
        // See 'ConnectionManager.php'  
        $connMgr = new ConnectionManager();      
        $pdo = $connMgr->getConnection();

        // STEP 2: Prepare SQL statement 
        $sql = 'select * from course order by course';
        $stmt = $pdo->prepare($sql);

        // STEP 3: Run SQL   
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        //STEP 4: Retrieve query results
        $results = [];
        while($row = $stmt->fetch()) {
            $results[] = new Course($row['course'], $row['school'], $row['title'],$row["description"],$row['exam_date'],$row['exam_start'],$row['exam_end']);
        }

        // STEP 5: Close DB Connection & SQL Statement         
        $stmt = null;         
        $pdo = null; 

        return $results;
    }   
    //Function 2: to extract information for a course
    public function retrieve($course) {       
        // STEP 1         
        // Connect to database          
        // See 'ConnectionManager.php'          
        $connMgr = new ConnectionManager();         
        $pdo = $connMgr->getConnection();  

        // STEP 2: Prepare SQL statement         
        $sql = ' SELECT * FROM course where course=:course ';        
        $stmt = $pdo->prepare($sql); 

        // STEP 3: Run SQL  
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);           
        $stmt->execute();         
        $stmt->setFetchMode(PDO::FETCH_ASSOC);// Retrieve each row as an Associative Array 

        // STEP 4: Retrieve query results        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            return new Course($row['course'], $row['school'], $row['title'],$row["description"],$row['exam_date'],$row['exam_start'],$row['exam_end']);
        }
        // STEP 5: Close DB Connection & SQL Statement         
        $stmt = null;         
        $pdo = null;     

    }
    //Function 3: to extract a course by its title
    public function retrieveByTitle($title) {       
        // STEP 1         
        // Connect to database          
        // See 'ConnectionManager.php'          
        $connMgr = new ConnectionManager();         
        $pdo = $connMgr->getConnection();  

        // STEP 2: Prepare SQL statement
        $title=  "%".$title."%";
        $sql = " SELECT * FROM course where title like :title ";        
        $stmt = $pdo->prepare($sql); 

        // STEP 3: Run SQL  
        $stmt->bindParam(':title', $title, PDO::PARAM_STR);           
        $stmt->execute();         
        $stmt->setFetchMode(PDO::FETCH_ASSOC);// Retrieve each row as an Associative Array 

        // STEP 4: Retrieve query results 
        $results = [];
        while($row = $stmt->fetch()) {
            $results[] = new Course($row['course'], $row['school'], $row['title'],$row["description"],$row['exam_date'],$row['exam_start'],$row['exam_end']);
        } 
        

        // STEP 5: Close DB Connection & SQL Statement         
        $stmt = null;         
        $pdo = null; 

        // STEP 6: return the array        
        return $results ;     

    }
    //Function 4: to extract courses under a school
    public function retrieveBySchool($school){
        // STEP 1         
        // Connect to database          
        // See 'ConnectionManager.php'  
        $connMgr = new ConnectionManager();      
        $pdo = $connMgr->getConnection();

        // STEP 2: Prepare SQL statement 
        $sql = 'select * from course where school=:school';
        $stmt = $pdo->prepare($sql);

        // STEP 3: Run SQL   
        $stmt->bindParam(':school', $school, PDO::PARAM_STR);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        //STEP 4: Retrieve query results
        $results = [];
        while($row = $stmt->fetch()) {
            $results[] = new Course($row['course'], $row['school'], $row['title'],$row["description"],$row['exam_date'],$row['exam_start'],$row['exam_end']);
        }

        // STEP 5: Close DB Connection & SQL Statement         
        $stmt = null;         
        $pdo = null; 

        return $results;
        }

    //Function 5: to add in new courses
    public function add($course) {
        
        $connMgr = new ConnectionManager();      
        $pdo = $connMgr->getConnection();
       
        $sql = 'INSERT IGNORE into course(course, school, title, description, exam_date, exam_start, exam_end) values (:course, :school, :title, :description, :exam_date, :exam_start, :exam_end)';
        
        $stmt = $pdo->prepare($sql);

        $stmt->bindParam(':course', $course->course, PDO::PARAM_STR);
        $stmt->bindParam(':school', $course->school, PDO::PARAM_STR);
        $stmt->bindParam(':title', $course->title, PDO::PARAM_STR);
        $stmt->bindParam(':description', $course->description, PDO::PARAM_STR);
        $stmt->bindParam(':exam_date', $course->exam_date, PDO::PARAM_STR);
        $stmt->bindParam(':exam_start', $course->exam_start, PDO::PARAM_STR);
        $stmt->bindParam(':exam_end', $course->exam_end, PDO::PARAM_STR);

        $isAddOK = False;
        if ($stmt->execute()) {
            $isAddOK = True;
        }

        $stmt = null;
        $pdo = null;

        return $isAddOK;
    }


    //Function 6: to remove all
    public function removeAll() {

        $connMgr = new ConnectionManager();
        $pdo= $connMgr->getConnection();

        $sql = 'TRUNCATE TABLE course';

        $stmt = $pdo->prepare($sql);
        $stmt->execute();

        $count = $stmt->rowCount();

        $stmt = null;
        $pdo = null;
    }
    
    //Function 7: to extract course by school and course
    public function retrieveBySchoolCourse($school,$course){
        // STEP 1         
        // Connect to database          
        // See 'ConnectionManager.php'  
        $connMgr = new ConnectionManager();      
        $pdo = $connMgr->getConnection();

        // STEP 2: Prepare SQL statement 
        $sql = 'select * from course where school=:school and course=:course';
        $stmt = $pdo->prepare($sql);

        // STEP 3: Run SQL   
        $stmt->bindParam(':school', $school, PDO::PARAM_STR);
        $stmt->bindParam(':course', $course, PDO::PARAM_STR);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        //STEP 4: Retrieve query results
        $results = [];
        while($row = $stmt->fetch()) {
            $results[] = new Course($row['course'], $row['school'], $row['title'],$row["description"],$row['exam_date'],$row['exam_start'],$row['exam_end']);
        }

        // STEP 5: Close DB Connection & SQL Statement         
        $stmt = null;         
        $pdo = null; 

        return $results;
        }

    }


?>