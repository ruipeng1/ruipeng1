<?php
class Enrolled{
    public $userid;
    public $course;
    public $section;
    public $amount;
    public $roundnum;
    public $stat;
    
    public function __construct($userid= '',$course= '',$section= '',$amount= '',$roundnum= '',$stat= ''){
        $this->userid = $userid;
        $this->course = $course;
        $this->section = $section;
        $this->amount = $amount;
        $this->roundnum = $roundnum;
        $this->stat = $stat;
    }

    public function getUserid(){
        return $this->userid;
    }

    public function getCourse(){
        return $this->course;
    }

    public function getSection(){
        return $this->section;
    }

    public function getAmount(){
        return $this->amount;
    }

    public function getRoundnum(){
        return $this->roundnum;
    }

    public function getStat(){
        return $this->stat;
    }
}
?>