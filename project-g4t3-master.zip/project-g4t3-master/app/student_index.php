<?php
require_once "include/protect.php";
require_once "include/common.php";

//If it is round 2, then call round 2 clearing logic (to display real time info)
$roundDAO = new RoundnumDAO();
$currRound = $roundDAO->retrieveAll()->getRound();
if ($currRound==2){
    require_once "round2_logic.php";
}  

//Student info
$dao = new StudentDAO();
$userid = $_SESSION['userid'];
$user = $dao->retrieve($userid);
$name = $user->getName();
$edollar = round($user->getEdollar(),2);

//DAO objects
$sectionDAO = new SectionDAO();
$enrolledDAO=new EnrolledDAO();
$courseDAO = new CourseDAO();
$bidDAO = new BidDAO();
$minBidDAO = new minBidDAO();
$course_completedDAO = new Course_completedDAO();
$courseDAO = new CourseDAO();

//navigation tabs
$nav_tab = "Cart";
$nav_tab_url = "cart.php";
$nav_tab_1 = "Logout";
$nav_tab_url_1 = "logout.php";
$nav_tab_2 = "Home";
$nav_tab_url_2 = "student_index.php";

//----------------------------------------------------To drop selected bids------------------------------------------------------------//

if(isset($_POST["to_drop_bid"])){
    $arr=$_POST["to_drop_bid"];
    foreach($arr as $str){
        $row = explode(",",$str);//var_dump($row);
        $rUser=$row[0];
        $rAmt=$row[1];
        $rCode=$row[2];
        $rSec=$row[3];
        $bid_to_drop=new Bid($rUser, $rAmt, $rCode, $rSec);
        $bidDAO->refund_when_drop($rUser, $rAmt);
        $bidDAO->drop($bid_to_drop);
        echo "<meta http-equiv='refresh' content='0;url=student_index.php'>";
    }
    
}

//--------------------------------------------------To drop selected enrolled sections------------------------------------------------//

if(isset($_POST["to_drop_enrolled"])){
    $arr=$_POST["to_drop_enrolled"];
    foreach($arr as $str){
        $row = explode(",",$str);//var_dump($row);
        $rUser=$row[0];
        $rAmt=$row[1];
        $rCode=$row[2];
        $rSec=$row[3];
        $enrolled_to_drop=new Enrolled($rUser, $rCode, $rSec, $rAmt);
        $enrolledDAO->refund_when_drop($rUser, $rAmt);
        $enrolledDAO->drop($enrolled_to_drop);
        $sectionDAO->updateSize($rCode,$rSec,1);
        //in 2nd round, if drop a section must drop a bid as well, else the bid will be enrolled again
        echo "<meta http-equiv='refresh' content='0;url=student_index.php'>";
    }
}

$_SESSION['student_index']='active';

?>


<!DOCTYPE html>
<html lang="en">
    <?php require_once 'include/head.php'; ?>   
    <body>
        <?php require_once 'include/nav.php'?>
        

        <div class="container"  >
            <div class="jumbotron">
                <?php
                // to show round status as title
                if($currRound=="stop1"){
                    echo "<h1 class='display-6' style ='text-align:center;'>ROUND 1 BIOS BIDDING ENDED</h1>";
                }elseif($currRound=="stop2"){
                    echo "<h1 class='display-6' style ='text-align:center;'>ROUND 2 BIOS BIDDING ENDED</h1>";
                }else{
                    echo "<h1 class='display-6' style ='text-align:center;'>ROUND $currRound BIOS BIDDING</h1>";
                }
                ?>
                
                <p  style ="text-align:center;">Welcome! <?=$name?>, you currently have<br/><b style="font-size: 40px;"><?=$edollar?></b><br/>edollars</p>   
            </div>
        </div>
<!--------------------------------------------------To show sections enrolled------------------------------------------------------------->
        <div class="container">
            <div class="row">
                <div class="col bid">
                    <h6>CURRENTLY ENROLLED</h6>
                    <table class='table table-sm table-striped currentBidRow'>
                        <thead>
                            <tr>
                                <td></td>
                                <td>Code</td>
                                <td>Course Title</td>
                                <td>Section</td>
                                <td>Amount</td>
                            </tr>
                        </thead>
                    <form action='student_index.php' method='POST'>
                        <?php
                            //only display successful enrolled from enrolled table
                            if ($currRound!="2"){
                                $success_enrolls = $enrolledDAO->retrieve_user_success_enrolled($userid);//var_dump($success_enrolls);
                            }else{
                                //*new*
                                //for round 2, only to display the round 1 enrolled course(based on wiki requirement)
                                $success_enrolls=$enrolledDAO->retrieve_round_success($userid,"stop1");
                            }
  
                            if($currRound!="1" ){

                                foreach($success_enrolls as $enrolled){

                                    $courseID = $enrolled->getCourse();
                                    $course = $courseDAO->retrieve($courseID);
                                    $coursename = $course->getTitle();
                                    $section=$enrolled->getSection();
                                    $amt=round($enrolled->getAmount(),2);
                                    
                                    echo   "<tr>";
                                    //dont show drop-course checkbox when round is inactive
                                    if(!empty($success_enrolls) && $currRound=="2" ){
                                        echo "<td><input type='checkbox' name='to_drop_enrolled[]' value='$userid,$amt,$courseID,$section'} </td>";
                                    }else{
                                        echo "<td></td>";
                                    }
                                    echo   "<td>$courseID</td>";   
                                    echo   "<td>$coursename</td>";     
                                    echo   "<td>$section</td>"; 
                                    echo   "<td>\$$amt</td>";          
                                    echo   "</tr>";
                            
                                }
                            
                            } 
                            echo "</table>";

                            // dont show drop-course button when round is inactive
                            if(empty($success_enrolls)||$currRound=="1" ){
                                echo "You are not enrolled in any courses.<br><br>";
                            }else if(!empty($success_enrolls) && $currRound=="2" ){
                                echo '<button type="submit"  value="drop" class="btn btn-secondary btn-sm" style="float:right";>Drop Enrolled Section</button>';
                            }else if(!empty($success_enrolls) && ($currRound=="stop2"|| $currRound=="stop1" )){
                                echo "The round is not active. You are not allowed to drop courses.<br><br>";
                            }
                        
                            
                        ?>
                    </form>
                </div>   
<!------------------------------------------------------To show Current Bids / Bid Results---------------------------------------------> 
    
                <div class="col bid">  
                    <?php
                        if($currRound=='1' || $currRound=='2'){
                            echo "<h6>CURRENT BIDS</h6>";
                        }elseif($currRound=='stop1'||$currRound=='stop2'){
                            echo "<h6>BIDDING RESULTS</h6>";
                        }
                    ?>
                    <a href = 'search_for_courses.php'><button type='button' class='btn btn-outline-secondary btn-sm' style='float:right; margin-top:-30px;'>Add More</button></a> 
                    <?php
                    ?>
                    <form action='student_index.php' method='POST'>
                    <?php

                    if($currRound=='stop1'||$currRound=='2'){
                        $enrollCurrStat = $enrolledDAO->retrieve_round($userid,$currRound);
                    }else if($currRound=='stop2'){
                        $enrollCurrStat = $enrolledDAO->retrieve_round($userid,"2");

                    }
                    $bid_list = $bidDAO->retrieve($userid);

                    echo"<table class='table table-sm table-striped currentBidRow'>
                            <thead>
                                <tr>
                                    <td></td>
                                    <td>Code</td>
                                    <td>Course Title</td>
                                    <td>Section</td>
                                    <td>Amount</td>
                                    <td>Result</td>";
                                    if($currRound=='2'||$currRound=='stop2'){
                                        echo "<td>Min Bid</td>";
                                        echo "<td>Vacancy</td>";
                                    }
                    echo       "</tr>
                            </thead>"; 

                    // display enrolled bids when round is 'stop1', 'stop2','2'
                    if($currRound=='stop1'||$currRound=='2'||$currRound=='stop2'){

                            foreach($enrollCurrStat as $enrolled){
                                
                                $courseCurrStat = $courseDAO->retrieve($enrolled->getCourse());
                                echo    "<tr>";

                                if($currRound=='2'){    
                                    echo "<td> <input type='checkbox' name='to_drop_bid[]' value='$userid,{$enrolled->getAmount()},{$enrolled->getCourse()},{$enrolled->getSection()}'> </td>";
                                }else{
                                    echo "<td></td>";
                                }
                                $enrollAmt = round($enrolled->getAmount(),2);
                                echo   "<td>{$enrolled->getCourse()}</td>
                                        <td>{$courseCurrStat->getTitle()}</td>
                                        <td>{$enrolled->getSection()}</td>
                                        <td>\${$enrollAmt}</td>";
                                        $stat=$enrolled->getStat();
                                        //show status in color
                                        if ($stat=="unsuccessful"){
                                            echo "<td style='color:red'>Fail</td>";
                                        }else if($stat=="successful"){
                                            echo "<td style='color:green'>Success</td>";
                                        }
                                        
                                        //show round 2 min bid & vacancy
                                        $minbid=$minBidDAO->retrieve_bid($enrolled->getCourse(),$enrolled->getSection())->getedollar();
                                        if($currRound!='stop1'){
                                            if($minbid==10.001){
                                                echo "<td>-</td>";
                                                echo "<td>0 after Round 1</td>";

                                            }elseif ($currRound=='2'){
                                                echo "<td>\$$minbid</td>";
                                                $sec_object=$sectionDAO->retrieve($enrolled->getCourse(),$enrolled->getSection());
                                                $size=$sec_object->getSize();//real size
                                                $size_after_round1=$size+sizeof($enrolledDAO->retrieve_success_enrolled($enrolled->getCourse(),$enrolled->getSection(),"2"));
                                                echo "<td>$size_after_round1</td>";

                                            }elseif($currRound=='stop2'){
                                                echo "<td>\$$minbid</td>";
                                                $sec_object=$sectionDAO->retrieve($enrolled->getCourse(),$enrolled->getSection());
                                                $size=$sec_object->getSize();//real size
                                                echo "<td>$size</td>";
                                            }

                                        }
                                        
                                echo    "</tr>";
                            }
                                
                    }else{// in round 1, display bids from bid table 
                        
                        foreach($bid_list as $bid){
                            $courseID = $bid->getCourse();
                            $course = $courseDAO->retrieve($courseID);
                            $coursename = $course->getTitle();
                            $section=$bid->getSection();
                            $amt=round($bid->getAmount(),2);
                            echo   "<tr>";
                            echo "<td><input type='checkbox' name='to_drop_bid[]' value='$userid,$amt,$courseID,$section'} </td>";
                            echo   "<td>$courseID</td>";   
                            echo   "<td>$coursename</td>";     
                            echo   "<td>$section</td>"; 
                            echo   "<td>\$$amt</td>"; 
                            echo   "<td>Pending</td>"; 
                        }
                    }   

                    echo    "</table>";

                    
                    if(($currRound=='1'||$currRound=='2')){
                        if(!empty($bid_list)){
                            echo '<button type="submit" value="drop" class="btn btn-secondary btn-sm" style="float:right">Drop Bid</button>';
                        }else{
                            echo "You haven't placed any bids yet.";
                        }
                    }
                    ?>
                    </form>
                </div>
            </div>
<!-------------------------------------------------To show Courses Completed------------------------------------------------------------->
            <div class="row">
                <div class="col bid">
                    <h6>COURSES COMPLETED</h6>
                    <?php
                        $course_completed_list = $course_completedDAO->retrieve($userid);//array
                        //course completed into session to pass to search_for_courses - so it doesnt show in table if you have completed
                        unset($_SESSION['completedCourse']);
                        foreach($course_completed_list as $cc_item){
                            $_SESSION['completedCourse'][]=$cc_item->getCode();
                        }
              
                        echo "
                            <table class='table table-sm table-striped' style='margin-top:3%;'>
                                <thead>
                                    <tr>
                                        <td>Code</td>
                                        <td>Course Title</td>
                                    </tr>
                                </thead><tbody>";  
                        if(!empty($course_completed_list)){
                            foreach($course_completed_list as $course_completed){
                                echo   "<tr>";
                                //to get Course ID
                                $courseID = $course_completed->getCode();
                                echo   "<td>$courseID</td>";   
                                //to get Course Title
                                $course = $courseDAO->retrieve($courseID);
                                $coursename = $course->getTitle();
                                echo   "<td>$coursename</td>";        
                                echo   "</tr>";
                                
                            }
                            echo "</tbody></table>";
                        }else{
                            echo "</tbody></table>
                            You have not completed any courses yet.
                            ";
                        }
                        
                    ?>
                </div>
                <div class="col bid">
                </div>
            </div>
        </div>
        <!-- comment out if want footer-->
  
    </body>
</html>

